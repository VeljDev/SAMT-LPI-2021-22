// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// **************************************************************************
// MoorGenerator
// **************************************************************************

// ignore_for_file: unnecessary_brace_in_string_interps, unnecessary_this
class GruppoData extends DataClass implements Insertable<GruppoData> {
  final int id;
  final String nome;
  final String descrizione;
  GruppoData({required this.id, required this.nome, required this.descrizione});
  factory GruppoData.fromData(Map<String, dynamic> data, {String? prefix}) {
    final effectivePrefix = prefix ?? '';
    return GruppoData(
      id: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}id'])!,
      nome: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}nome'])!,
      descrizione: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}descrizione'])!,
    );
  }
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['nome'] = Variable<String>(nome);
    map['descrizione'] = Variable<String>(descrizione);
    return map;
  }

  GruppoCompanion toCompanion(bool nullToAbsent) {
    return GruppoCompanion(
      id: Value(id),
      nome: Value(nome),
      descrizione: Value(descrizione),
    );
  }

  factory GruppoData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GruppoData(
      id: serializer.fromJson<int>(json['id']),
      nome: serializer.fromJson<String>(json['nome']),
      descrizione: serializer.fromJson<String>(json['descrizione']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'nome': serializer.toJson<String>(nome),
      'descrizione': serializer.toJson<String>(descrizione),
    };
  }

  GruppoData copyWith({int? id, String? nome, String? descrizione}) =>
      GruppoData(
        id: id ?? this.id,
        nome: nome ?? this.nome,
        descrizione: descrizione ?? this.descrizione,
      );
  @override
  String toString() {
    return (StringBuffer('GruppoData(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descrizione: $descrizione')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descrizione);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GruppoData &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descrizione == this.descrizione);
}

class GruppoCompanion extends UpdateCompanion<GruppoData> {
  final Value<int> id;
  final Value<String> nome;
  final Value<String> descrizione;
  const GruppoCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descrizione = const Value.absent(),
  });
  GruppoCompanion.insert({
    this.id = const Value.absent(),
    required String nome,
    required String descrizione,
  })  : nome = Value(nome),
        descrizione = Value(descrizione);
  static Insertable<GruppoData> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descrizione,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descrizione != null) 'descrizione': descrizione,
    });
  }

  GruppoCompanion copyWith(
      {Value<int>? id, Value<String>? nome, Value<String>? descrizione}) {
    return GruppoCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descrizione: descrizione ?? this.descrizione,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descrizione.present) {
      map['descrizione'] = Variable<String>(descrizione.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GruppoCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descrizione: $descrizione')
          ..write(')'))
        .toString();
  }
}

class Gruppo extends Table with TableInfo<Gruppo, GruppoData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  Gruppo(this.attachedDatabase, [this._alias]);
  final VerificationMeta _idMeta = const VerificationMeta('id');
  late final GeneratedColumn<int?> id = GeneratedColumn<int?>(
      'id', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: false,
      $customConstraints: 'NOT NULL PRIMARY KEY');
  final VerificationMeta _nomeMeta = const VerificationMeta('nome');
  late final GeneratedColumn<String?> nome = GeneratedColumn<String?>(
      'nome', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _descrizioneMeta =
      const VerificationMeta('descrizione');
  late final GeneratedColumn<String?> descrizione = GeneratedColumn<String?>(
      'descrizione', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  @override
  List<GeneratedColumn> get $columns => [id, nome, descrizione];
  @override
  String get aliasedName => _alias ?? 'gruppo';
  @override
  String get actualTableName => 'gruppo';
  @override
  VerificationContext validateIntegrity(Insertable<GruppoData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    } else if (isInserting) {
      context.missing(_nomeMeta);
    }
    if (data.containsKey('descrizione')) {
      context.handle(
          _descrizioneMeta,
          descrizione.isAcceptableOrUnknown(
              data['descrizione']!, _descrizioneMeta));
    } else if (isInserting) {
      context.missing(_descrizioneMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GruppoData map(Map<String, dynamic> data, {String? tablePrefix}) {
    return GruppoData.fromData(data,
        prefix: tablePrefix != null ? '$tablePrefix.' : null);
  }

  @override
  Gruppo createAlias(String alias) {
    return Gruppo(attachedDatabase, alias);
  }

  @override
  bool get dontWriteConstraints => true;
}

class TipoData extends DataClass implements Insertable<TipoData> {
  final String valore;
  TipoData({required this.valore});
  factory TipoData.fromData(Map<String, dynamic> data, {String? prefix}) {
    final effectivePrefix = prefix ?? '';
    return TipoData(
      valore: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}valore'])!,
    );
  }
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['valore'] = Variable<String>(valore);
    return map;
  }

  TipoCompanion toCompanion(bool nullToAbsent) {
    return TipoCompanion(
      valore: Value(valore),
    );
  }

  factory TipoData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TipoData(
      valore: serializer.fromJson<String>(json['valore']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'valore': serializer.toJson<String>(valore),
    };
  }

  TipoData copyWith({String? valore}) => TipoData(
        valore: valore ?? this.valore,
      );
  @override
  String toString() {
    return (StringBuffer('TipoData(')
          ..write('valore: $valore')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => valore.hashCode;
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TipoData && other.valore == this.valore);
}

class TipoCompanion extends UpdateCompanion<TipoData> {
  final Value<String> valore;
  const TipoCompanion({
    this.valore = const Value.absent(),
  });
  TipoCompanion.insert({
    required String valore,
  }) : valore = Value(valore);
  static Insertable<TipoData> custom({
    Expression<String>? valore,
  }) {
    return RawValuesInsertable({
      if (valore != null) 'valore': valore,
    });
  }

  TipoCompanion copyWith({Value<String>? valore}) {
    return TipoCompanion(
      valore: valore ?? this.valore,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (valore.present) {
      map['valore'] = Variable<String>(valore.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TipoCompanion(')
          ..write('valore: $valore')
          ..write(')'))
        .toString();
  }
}

class Tipo extends Table with TableInfo<Tipo, TipoData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  Tipo(this.attachedDatabase, [this._alias]);
  final VerificationMeta _valoreMeta = const VerificationMeta('valore');
  late final GeneratedColumn<String?> valore = GeneratedColumn<String?>(
      'valore', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL PRIMARY KEY');
  @override
  List<GeneratedColumn> get $columns => [valore];
  @override
  String get aliasedName => _alias ?? 'tipo';
  @override
  String get actualTableName => 'tipo';
  @override
  VerificationContext validateIntegrity(Insertable<TipoData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('valore')) {
      context.handle(_valoreMeta,
          valore.isAcceptableOrUnknown(data['valore']!, _valoreMeta));
    } else if (isInserting) {
      context.missing(_valoreMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {valore};
  @override
  TipoData map(Map<String, dynamic> data, {String? tablePrefix}) {
    return TipoData.fromData(data,
        prefix: tablePrefix != null ? '$tablePrefix.' : null);
  }

  @override
  Tipo createAlias(String alias) {
    return Tipo(attachedDatabase, alias);
  }

  @override
  bool get dontWriteConstraints => true;
}

class GradoData extends DataClass implements Insertable<GradoData> {
  final String valore;
  GradoData({required this.valore});
  factory GradoData.fromData(Map<String, dynamic> data, {String? prefix}) {
    final effectivePrefix = prefix ?? '';
    return GradoData(
      valore: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}valore'])!,
    );
  }
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['valore'] = Variable<String>(valore);
    return map;
  }

  GradoCompanion toCompanion(bool nullToAbsent) {
    return GradoCompanion(
      valore: Value(valore),
    );
  }

  factory GradoData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GradoData(
      valore: serializer.fromJson<String>(json['valore']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'valore': serializer.toJson<String>(valore),
    };
  }

  GradoData copyWith({String? valore}) => GradoData(
        valore: valore ?? this.valore,
      );
  @override
  String toString() {
    return (StringBuffer('GradoData(')
          ..write('valore: $valore')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => valore.hashCode;
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GradoData && other.valore == this.valore);
}

class GradoCompanion extends UpdateCompanion<GradoData> {
  final Value<String> valore;
  const GradoCompanion({
    this.valore = const Value.absent(),
  });
  GradoCompanion.insert({
    required String valore,
  }) : valore = Value(valore);
  static Insertable<GradoData> custom({
    Expression<String>? valore,
  }) {
    return RawValuesInsertable({
      if (valore != null) 'valore': valore,
    });
  }

  GradoCompanion copyWith({Value<String>? valore}) {
    return GradoCompanion(
      valore: valore ?? this.valore,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (valore.present) {
      map['valore'] = Variable<String>(valore.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GradoCompanion(')
          ..write('valore: $valore')
          ..write(')'))
        .toString();
  }
}

class Grado extends Table with TableInfo<Grado, GradoData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  Grado(this.attachedDatabase, [this._alias]);
  final VerificationMeta _valoreMeta = const VerificationMeta('valore');
  late final GeneratedColumn<String?> valore = GeneratedColumn<String?>(
      'valore', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL PRIMARY KEY');
  @override
  List<GeneratedColumn> get $columns => [valore];
  @override
  String get aliasedName => _alias ?? 'grado';
  @override
  String get actualTableName => 'grado';
  @override
  VerificationContext validateIntegrity(Insertable<GradoData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('valore')) {
      context.handle(_valoreMeta,
          valore.isAcceptableOrUnknown(data['valore']!, _valoreMeta));
    } else if (isInserting) {
      context.missing(_valoreMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {valore};
  @override
  GradoData map(Map<String, dynamic> data, {String? tablePrefix}) {
    return GradoData.fromData(data,
        prefix: tablePrefix != null ? '$tablePrefix.' : null);
  }

  @override
  Grado createAlias(String alias) {
    return Grado(attachedDatabase, alias);
  }

  @override
  bool get dontWriteConstraints => true;
}

class RuoloData extends DataClass implements Insertable<RuoloData> {
  final String valore;
  RuoloData({required this.valore});
  factory RuoloData.fromData(Map<String, dynamic> data, {String? prefix}) {
    final effectivePrefix = prefix ?? '';
    return RuoloData(
      valore: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}valore'])!,
    );
  }
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['valore'] = Variable<String>(valore);
    return map;
  }

  RuoloCompanion toCompanion(bool nullToAbsent) {
    return RuoloCompanion(
      valore: Value(valore),
    );
  }

  factory RuoloData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RuoloData(
      valore: serializer.fromJson<String>(json['valore']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'valore': serializer.toJson<String>(valore),
    };
  }

  RuoloData copyWith({String? valore}) => RuoloData(
        valore: valore ?? this.valore,
      );
  @override
  String toString() {
    return (StringBuffer('RuoloData(')
          ..write('valore: $valore')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => valore.hashCode;
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RuoloData && other.valore == this.valore);
}

class RuoloCompanion extends UpdateCompanion<RuoloData> {
  final Value<String> valore;
  const RuoloCompanion({
    this.valore = const Value.absent(),
  });
  RuoloCompanion.insert({
    required String valore,
  }) : valore = Value(valore);
  static Insertable<RuoloData> custom({
    Expression<String>? valore,
  }) {
    return RawValuesInsertable({
      if (valore != null) 'valore': valore,
    });
  }

  RuoloCompanion copyWith({Value<String>? valore}) {
    return RuoloCompanion(
      valore: valore ?? this.valore,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (valore.present) {
      map['valore'] = Variable<String>(valore.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RuoloCompanion(')
          ..write('valore: $valore')
          ..write(')'))
        .toString();
  }
}

class Ruolo extends Table with TableInfo<Ruolo, RuoloData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  Ruolo(this.attachedDatabase, [this._alias]);
  final VerificationMeta _valoreMeta = const VerificationMeta('valore');
  late final GeneratedColumn<String?> valore = GeneratedColumn<String?>(
      'valore', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL PRIMARY KEY');
  @override
  List<GeneratedColumn> get $columns => [valore];
  @override
  String get aliasedName => _alias ?? 'ruolo';
  @override
  String get actualTableName => 'ruolo';
  @override
  VerificationContext validateIntegrity(Insertable<RuoloData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('valore')) {
      context.handle(_valoreMeta,
          valore.isAcceptableOrUnknown(data['valore']!, _valoreMeta));
    } else if (isInserting) {
      context.missing(_valoreMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {valore};
  @override
  RuoloData map(Map<String, dynamic> data, {String? tablePrefix}) {
    return RuoloData.fromData(data,
        prefix: tablePrefix != null ? '$tablePrefix.' : null);
  }

  @override
  Ruolo createAlias(String alias) {
    return Ruolo(attachedDatabase, alias);
  }

  @override
  bool get dontWriteConstraints => true;
}

class DipendenteData extends DataClass implements Insertable<DipendenteData> {
  final int id;
  final String nome;
  final String cognome;
  final String sesso;
  final String cellulare;
  final String indirizzo;
  final int cap;
  final String localita;
  final String dataNascita;
  final String dataAffiliazione;
  final String? note;
  final int gruppo;
  final String grado;
  final String tipo;
  final String ruolo;
  DipendenteData(
      {required this.id,
      required this.nome,
      required this.cognome,
      required this.sesso,
      required this.cellulare,
      required this.indirizzo,
      required this.cap,
      required this.localita,
      required this.dataNascita,
      required this.dataAffiliazione,
      this.note,
      required this.gruppo,
      required this.grado,
      required this.tipo,
      required this.ruolo});
  factory DipendenteData.fromData(Map<String, dynamic> data, {String? prefix}) {
    final effectivePrefix = prefix ?? '';
    return DipendenteData(
      id: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}id'])!,
      nome: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}nome'])!,
      cognome: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}cognome'])!,
      sesso: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}sesso'])!,
      cellulare: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}cellulare'])!,
      indirizzo: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}indirizzo'])!,
      cap: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}CAP'])!,
      localita: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}localita'])!,
      dataNascita: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}data_nascita'])!,
      dataAffiliazione: const StringType().mapFromDatabaseResponse(
          data['${effectivePrefix}data_affiliazione'])!,
      note: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}note']),
      gruppo: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}gruppo'])!,
      grado: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}grado'])!,
      tipo: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}tipo'])!,
      ruolo: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}ruolo'])!,
    );
  }
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['nome'] = Variable<String>(nome);
    map['cognome'] = Variable<String>(cognome);
    map['sesso'] = Variable<String>(sesso);
    map['cellulare'] = Variable<String>(cellulare);
    map['indirizzo'] = Variable<String>(indirizzo);
    map['CAP'] = Variable<int>(cap);
    map['localita'] = Variable<String>(localita);
    map['data_nascita'] = Variable<String>(dataNascita);
    map['data_affiliazione'] = Variable<String>(dataAffiliazione);
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String?>(note);
    }
    map['gruppo'] = Variable<int>(gruppo);
    map['grado'] = Variable<String>(grado);
    map['tipo'] = Variable<String>(tipo);
    map['ruolo'] = Variable<String>(ruolo);
    return map;
  }

  DipendenteCompanion toCompanion(bool nullToAbsent) {
    return DipendenteCompanion(
      id: Value(id),
      nome: Value(nome),
      cognome: Value(cognome),
      sesso: Value(sesso),
      cellulare: Value(cellulare),
      indirizzo: Value(indirizzo),
      cap: Value(cap),
      localita: Value(localita),
      dataNascita: Value(dataNascita),
      dataAffiliazione: Value(dataAffiliazione),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
      gruppo: Value(gruppo),
      grado: Value(grado),
      tipo: Value(tipo),
      ruolo: Value(ruolo),
    );
  }

  factory DipendenteData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DipendenteData(
      id: serializer.fromJson<int>(json['id']),
      nome: serializer.fromJson<String>(json['nome']),
      cognome: serializer.fromJson<String>(json['cognome']),
      sesso: serializer.fromJson<String>(json['sesso']),
      cellulare: serializer.fromJson<String>(json['cellulare']),
      indirizzo: serializer.fromJson<String>(json['indirizzo']),
      cap: serializer.fromJson<int>(json['CAP']),
      localita: serializer.fromJson<String>(json['localita']),
      dataNascita: serializer.fromJson<String>(json['data_nascita']),
      dataAffiliazione: serializer.fromJson<String>(json['data_affiliazione']),
      note: serializer.fromJson<String?>(json['note']),
      gruppo: serializer.fromJson<int>(json['gruppo']),
      grado: serializer.fromJson<String>(json['grado']),
      tipo: serializer.fromJson<String>(json['tipo']),
      ruolo: serializer.fromJson<String>(json['ruolo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'nome': serializer.toJson<String>(nome),
      'cognome': serializer.toJson<String>(cognome),
      'sesso': serializer.toJson<String>(sesso),
      'cellulare': serializer.toJson<String>(cellulare),
      'indirizzo': serializer.toJson<String>(indirizzo),
      'CAP': serializer.toJson<int>(cap),
      'localita': serializer.toJson<String>(localita),
      'data_nascita': serializer.toJson<String>(dataNascita),
      'data_affiliazione': serializer.toJson<String>(dataAffiliazione),
      'note': serializer.toJson<String?>(note),
      'gruppo': serializer.toJson<int>(gruppo),
      'grado': serializer.toJson<String>(grado),
      'tipo': serializer.toJson<String>(tipo),
      'ruolo': serializer.toJson<String>(ruolo),
    };
  }

  DipendenteData copyWith(
          {int? id,
          String? nome,
          String? cognome,
          String? sesso,
          String? cellulare,
          String? indirizzo,
          int? cap,
          String? localita,
          String? dataNascita,
          String? dataAffiliazione,
          String? note,
          int? gruppo,
          String? grado,
          String? tipo,
          String? ruolo}) =>
      DipendenteData(
        id: id ?? this.id,
        nome: nome ?? this.nome,
        cognome: cognome ?? this.cognome,
        sesso: sesso ?? this.sesso,
        cellulare: cellulare ?? this.cellulare,
        indirizzo: indirizzo ?? this.indirizzo,
        cap: cap ?? this.cap,
        localita: localita ?? this.localita,
        dataNascita: dataNascita ?? this.dataNascita,
        dataAffiliazione: dataAffiliazione ?? this.dataAffiliazione,
        note: note ?? this.note,
        gruppo: gruppo ?? this.gruppo,
        grado: grado ?? this.grado,
        tipo: tipo ?? this.tipo,
        ruolo: ruolo ?? this.ruolo,
      );
  @override
  String toString() {
    return (StringBuffer('DipendenteData(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('cognome: $cognome, ')
          ..write('sesso: $sesso, ')
          ..write('cellulare: $cellulare, ')
          ..write('indirizzo: $indirizzo, ')
          ..write('cap: $cap, ')
          ..write('localita: $localita, ')
          ..write('dataNascita: $dataNascita, ')
          ..write('dataAffiliazione: $dataAffiliazione, ')
          ..write('note: $note, ')
          ..write('gruppo: $gruppo, ')
          ..write('grado: $grado, ')
          ..write('tipo: $tipo, ')
          ..write('ruolo: $ruolo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      nome,
      cognome,
      sesso,
      cellulare,
      indirizzo,
      cap,
      localita,
      dataNascita,
      dataAffiliazione,
      note,
      gruppo,
      grado,
      tipo,
      ruolo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DipendenteData &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.cognome == this.cognome &&
          other.sesso == this.sesso &&
          other.cellulare == this.cellulare &&
          other.indirizzo == this.indirizzo &&
          other.cap == this.cap &&
          other.localita == this.localita &&
          other.dataNascita == this.dataNascita &&
          other.dataAffiliazione == this.dataAffiliazione &&
          other.note == this.note &&
          other.gruppo == this.gruppo &&
          other.grado == this.grado &&
          other.tipo == this.tipo &&
          other.ruolo == this.ruolo);
}

class DipendenteCompanion extends UpdateCompanion<DipendenteData> {
  final Value<int> id;
  final Value<String> nome;
  final Value<String> cognome;
  final Value<String> sesso;
  final Value<String> cellulare;
  final Value<String> indirizzo;
  final Value<int> cap;
  final Value<String> localita;
  final Value<String> dataNascita;
  final Value<String> dataAffiliazione;
  final Value<String?> note;
  final Value<int> gruppo;
  final Value<String> grado;
  final Value<String> tipo;
  final Value<String> ruolo;
  const DipendenteCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.cognome = const Value.absent(),
    this.sesso = const Value.absent(),
    this.cellulare = const Value.absent(),
    this.indirizzo = const Value.absent(),
    this.cap = const Value.absent(),
    this.localita = const Value.absent(),
    this.dataNascita = const Value.absent(),
    this.dataAffiliazione = const Value.absent(),
    this.note = const Value.absent(),
    this.gruppo = const Value.absent(),
    this.grado = const Value.absent(),
    this.tipo = const Value.absent(),
    this.ruolo = const Value.absent(),
  });
  DipendenteCompanion.insert({
    this.id = const Value.absent(),
    required String nome,
    required String cognome,
    required String sesso,
    required String cellulare,
    required String indirizzo,
    required int cap,
    required String localita,
    required String dataNascita,
    required String dataAffiliazione,
    this.note = const Value.absent(),
    required int gruppo,
    required String grado,
    required String tipo,
    required String ruolo,
  })  : nome = Value(nome),
        cognome = Value(cognome),
        sesso = Value(sesso),
        cellulare = Value(cellulare),
        indirizzo = Value(indirizzo),
        cap = Value(cap),
        localita = Value(localita),
        dataNascita = Value(dataNascita),
        dataAffiliazione = Value(dataAffiliazione),
        gruppo = Value(gruppo),
        grado = Value(grado),
        tipo = Value(tipo),
        ruolo = Value(ruolo);
  static Insertable<DipendenteData> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? cognome,
    Expression<String>? sesso,
    Expression<String>? cellulare,
    Expression<String>? indirizzo,
    Expression<int>? cap,
    Expression<String>? localita,
    Expression<String>? dataNascita,
    Expression<String>? dataAffiliazione,
    Expression<String?>? note,
    Expression<int>? gruppo,
    Expression<String>? grado,
    Expression<String>? tipo,
    Expression<String>? ruolo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (cognome != null) 'cognome': cognome,
      if (sesso != null) 'sesso': sesso,
      if (cellulare != null) 'cellulare': cellulare,
      if (indirizzo != null) 'indirizzo': indirizzo,
      if (cap != null) 'CAP': cap,
      if (localita != null) 'localita': localita,
      if (dataNascita != null) 'data_nascita': dataNascita,
      if (dataAffiliazione != null) 'data_affiliazione': dataAffiliazione,
      if (note != null) 'note': note,
      if (gruppo != null) 'gruppo': gruppo,
      if (grado != null) 'grado': grado,
      if (tipo != null) 'tipo': tipo,
      if (ruolo != null) 'ruolo': ruolo,
    });
  }

  DipendenteCompanion copyWith(
      {Value<int>? id,
      Value<String>? nome,
      Value<String>? cognome,
      Value<String>? sesso,
      Value<String>? cellulare,
      Value<String>? indirizzo,
      Value<int>? cap,
      Value<String>? localita,
      Value<String>? dataNascita,
      Value<String>? dataAffiliazione,
      Value<String?>? note,
      Value<int>? gruppo,
      Value<String>? grado,
      Value<String>? tipo,
      Value<String>? ruolo}) {
    return DipendenteCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      cognome: cognome ?? this.cognome,
      sesso: sesso ?? this.sesso,
      cellulare: cellulare ?? this.cellulare,
      indirizzo: indirizzo ?? this.indirizzo,
      cap: cap ?? this.cap,
      localita: localita ?? this.localita,
      dataNascita: dataNascita ?? this.dataNascita,
      dataAffiliazione: dataAffiliazione ?? this.dataAffiliazione,
      note: note ?? this.note,
      gruppo: gruppo ?? this.gruppo,
      grado: grado ?? this.grado,
      tipo: tipo ?? this.tipo,
      ruolo: ruolo ?? this.ruolo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (cognome.present) {
      map['cognome'] = Variable<String>(cognome.value);
    }
    if (sesso.present) {
      map['sesso'] = Variable<String>(sesso.value);
    }
    if (cellulare.present) {
      map['cellulare'] = Variable<String>(cellulare.value);
    }
    if (indirizzo.present) {
      map['indirizzo'] = Variable<String>(indirizzo.value);
    }
    if (cap.present) {
      map['CAP'] = Variable<int>(cap.value);
    }
    if (localita.present) {
      map['localita'] = Variable<String>(localita.value);
    }
    if (dataNascita.present) {
      map['data_nascita'] = Variable<String>(dataNascita.value);
    }
    if (dataAffiliazione.present) {
      map['data_affiliazione'] = Variable<String>(dataAffiliazione.value);
    }
    if (note.present) {
      map['note'] = Variable<String?>(note.value);
    }
    if (gruppo.present) {
      map['gruppo'] = Variable<int>(gruppo.value);
    }
    if (grado.present) {
      map['grado'] = Variable<String>(grado.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (ruolo.present) {
      map['ruolo'] = Variable<String>(ruolo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DipendenteCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('cognome: $cognome, ')
          ..write('sesso: $sesso, ')
          ..write('cellulare: $cellulare, ')
          ..write('indirizzo: $indirizzo, ')
          ..write('cap: $cap, ')
          ..write('localita: $localita, ')
          ..write('dataNascita: $dataNascita, ')
          ..write('dataAffiliazione: $dataAffiliazione, ')
          ..write('note: $note, ')
          ..write('gruppo: $gruppo, ')
          ..write('grado: $grado, ')
          ..write('tipo: $tipo, ')
          ..write('ruolo: $ruolo')
          ..write(')'))
        .toString();
  }
}

class Dipendente extends Table with TableInfo<Dipendente, DipendenteData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  Dipendente(this.attachedDatabase, [this._alias]);
  final VerificationMeta _idMeta = const VerificationMeta('id');
  late final GeneratedColumn<int?> id = GeneratedColumn<int?>(
      'id', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: false,
      $customConstraints: 'NOT NULL PRIMARY KEY AUTOINCREMENT');
  final VerificationMeta _nomeMeta = const VerificationMeta('nome');
  late final GeneratedColumn<String?> nome = GeneratedColumn<String?>(
      'nome', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _cognomeMeta = const VerificationMeta('cognome');
  late final GeneratedColumn<String?> cognome = GeneratedColumn<String?>(
      'cognome', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _sessoMeta = const VerificationMeta('sesso');
  late final GeneratedColumn<String?> sesso = GeneratedColumn<String?>(
      'sesso', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _cellulareMeta = const VerificationMeta('cellulare');
  late final GeneratedColumn<String?> cellulare = GeneratedColumn<String?>(
      'cellulare', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _indirizzoMeta = const VerificationMeta('indirizzo');
  late final GeneratedColumn<String?> indirizzo = GeneratedColumn<String?>(
      'indirizzo', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _capMeta = const VerificationMeta('cap');
  late final GeneratedColumn<int?> cap = GeneratedColumn<int?>(
      'CAP', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _localitaMeta = const VerificationMeta('localita');
  late final GeneratedColumn<String?> localita = GeneratedColumn<String?>(
      'localita', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _dataNascitaMeta =
      const VerificationMeta('dataNascita');
  late final GeneratedColumn<String?> dataNascita = GeneratedColumn<String?>(
      'data_nascita', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _dataAffiliazioneMeta =
      const VerificationMeta('dataAffiliazione');
  late final GeneratedColumn<String?> dataAffiliazione =
      GeneratedColumn<String?>('data_affiliazione', aliasedName, false,
          type: const StringType(),
          requiredDuringInsert: true,
          $customConstraints: 'NOT NULL');
  final VerificationMeta _noteMeta = const VerificationMeta('note');
  late final GeneratedColumn<String?> note = GeneratedColumn<String?>(
      'note', aliasedName, true,
      type: const StringType(),
      requiredDuringInsert: false,
      $customConstraints: '');
  final VerificationMeta _gruppoMeta = const VerificationMeta('gruppo');
  late final GeneratedColumn<int?> gruppo = GeneratedColumn<int?>(
      'gruppo', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _gradoMeta = const VerificationMeta('grado');
  late final GeneratedColumn<String?> grado = GeneratedColumn<String?>(
      'grado', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  late final GeneratedColumn<String?> tipo = GeneratedColumn<String?>(
      'tipo', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _ruoloMeta = const VerificationMeta('ruolo');
  late final GeneratedColumn<String?> ruolo = GeneratedColumn<String?>(
      'ruolo', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        cognome,
        sesso,
        cellulare,
        indirizzo,
        cap,
        localita,
        dataNascita,
        dataAffiliazione,
        note,
        gruppo,
        grado,
        tipo,
        ruolo
      ];
  @override
  String get aliasedName => _alias ?? 'dipendente';
  @override
  String get actualTableName => 'dipendente';
  @override
  VerificationContext validateIntegrity(Insertable<DipendenteData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    } else if (isInserting) {
      context.missing(_nomeMeta);
    }
    if (data.containsKey('cognome')) {
      context.handle(_cognomeMeta,
          cognome.isAcceptableOrUnknown(data['cognome']!, _cognomeMeta));
    } else if (isInserting) {
      context.missing(_cognomeMeta);
    }
    if (data.containsKey('sesso')) {
      context.handle(
          _sessoMeta, sesso.isAcceptableOrUnknown(data['sesso']!, _sessoMeta));
    } else if (isInserting) {
      context.missing(_sessoMeta);
    }
    if (data.containsKey('cellulare')) {
      context.handle(_cellulareMeta,
          cellulare.isAcceptableOrUnknown(data['cellulare']!, _cellulareMeta));
    } else if (isInserting) {
      context.missing(_cellulareMeta);
    }
    if (data.containsKey('indirizzo')) {
      context.handle(_indirizzoMeta,
          indirizzo.isAcceptableOrUnknown(data['indirizzo']!, _indirizzoMeta));
    } else if (isInserting) {
      context.missing(_indirizzoMeta);
    }
    if (data.containsKey('CAP')) {
      context.handle(
          _capMeta, cap.isAcceptableOrUnknown(data['CAP']!, _capMeta));
    } else if (isInserting) {
      context.missing(_capMeta);
    }
    if (data.containsKey('localita')) {
      context.handle(_localitaMeta,
          localita.isAcceptableOrUnknown(data['localita']!, _localitaMeta));
    } else if (isInserting) {
      context.missing(_localitaMeta);
    }
    if (data.containsKey('data_nascita')) {
      context.handle(
          _dataNascitaMeta,
          dataNascita.isAcceptableOrUnknown(
              data['data_nascita']!, _dataNascitaMeta));
    } else if (isInserting) {
      context.missing(_dataNascitaMeta);
    }
    if (data.containsKey('data_affiliazione')) {
      context.handle(
          _dataAffiliazioneMeta,
          dataAffiliazione.isAcceptableOrUnknown(
              data['data_affiliazione']!, _dataAffiliazioneMeta));
    } else if (isInserting) {
      context.missing(_dataAffiliazioneMeta);
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    if (data.containsKey('gruppo')) {
      context.handle(_gruppoMeta,
          gruppo.isAcceptableOrUnknown(data['gruppo']!, _gruppoMeta));
    } else if (isInserting) {
      context.missing(_gruppoMeta);
    }
    if (data.containsKey('grado')) {
      context.handle(
          _gradoMeta, grado.isAcceptableOrUnknown(data['grado']!, _gradoMeta));
    } else if (isInserting) {
      context.missing(_gradoMeta);
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    } else if (isInserting) {
      context.missing(_tipoMeta);
    }
    if (data.containsKey('ruolo')) {
      context.handle(
          _ruoloMeta, ruolo.isAcceptableOrUnknown(data['ruolo']!, _ruoloMeta));
    } else if (isInserting) {
      context.missing(_ruoloMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DipendenteData map(Map<String, dynamic> data, {String? tablePrefix}) {
    return DipendenteData.fromData(data,
        prefix: tablePrefix != null ? '$tablePrefix.' : null);
  }

  @override
  Dipendente createAlias(String alias) {
    return Dipendente(attachedDatabase, alias);
  }

  @override
  List<String> get customConstraints => const [
        'FOREIGN KEY(gruppo) REFERENCES gruppo(id) ON UPDATE CASCADE ON DELETE NO ACTION',
        'FOREIGN KEY(grado) REFERENCES grado(valore) ON UPDATE CASCADE ON DELETE NO ACTION',
        'FOREIGN KEY(tipo) REFERENCES tipo(valore) ON UPDATE CASCADE ON DELETE NO ACTION',
        'FOREIGN KEY(ruolo) REFERENCES ruolo(valore) ON UPDATE CASCADE ON DELETE NO ACTION'
      ];
  @override
  bool get dontWriteConstraints => true;
}

class StoricoData extends DataClass implements Insertable<StoricoData> {
  final int id;
  final String data;
  final String descrizione;
  final int dipendente;
  StoricoData(
      {required this.id,
      required this.data,
      required this.descrizione,
      required this.dipendente});
  factory StoricoData.fromData(Map<String, dynamic> data, {String? prefix}) {
    final effectivePrefix = prefix ?? '';
    return StoricoData(
      id: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}id'])!,
      data: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}data'])!,
      descrizione: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}descrizione'])!,
      dipendente: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}dipendente'])!,
    );
  }
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['data'] = Variable<String>(data);
    map['descrizione'] = Variable<String>(descrizione);
    map['dipendente'] = Variable<int>(dipendente);
    return map;
  }

  StoricoCompanion toCompanion(bool nullToAbsent) {
    return StoricoCompanion(
      id: Value(id),
      data: Value(data),
      descrizione: Value(descrizione),
      dipendente: Value(dipendente),
    );
  }

  factory StoricoData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return StoricoData(
      id: serializer.fromJson<int>(json['id']),
      data: serializer.fromJson<String>(json['data']),
      descrizione: serializer.fromJson<String>(json['descrizione']),
      dipendente: serializer.fromJson<int>(json['dipendente']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'data': serializer.toJson<String>(data),
      'descrizione': serializer.toJson<String>(descrizione),
      'dipendente': serializer.toJson<int>(dipendente),
    };
  }

  StoricoData copyWith(
          {int? id, String? data, String? descrizione, int? dipendente}) =>
      StoricoData(
        id: id ?? this.id,
        data: data ?? this.data,
        descrizione: descrizione ?? this.descrizione,
        dipendente: dipendente ?? this.dipendente,
      );
  @override
  String toString() {
    return (StringBuffer('StoricoData(')
          ..write('id: $id, ')
          ..write('data: $data, ')
          ..write('descrizione: $descrizione, ')
          ..write('dipendente: $dipendente')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, data, descrizione, dipendente);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is StoricoData &&
          other.id == this.id &&
          other.data == this.data &&
          other.descrizione == this.descrizione &&
          other.dipendente == this.dipendente);
}

class StoricoCompanion extends UpdateCompanion<StoricoData> {
  final Value<int> id;
  final Value<String> data;
  final Value<String> descrizione;
  final Value<int> dipendente;
  const StoricoCompanion({
    this.id = const Value.absent(),
    this.data = const Value.absent(),
    this.descrizione = const Value.absent(),
    this.dipendente = const Value.absent(),
  });
  StoricoCompanion.insert({
    this.id = const Value.absent(),
    required String data,
    required String descrizione,
    required int dipendente,
  })  : data = Value(data),
        descrizione = Value(descrizione),
        dipendente = Value(dipendente);
  static Insertable<StoricoData> custom({
    Expression<int>? id,
    Expression<String>? data,
    Expression<String>? descrizione,
    Expression<int>? dipendente,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (data != null) 'data': data,
      if (descrizione != null) 'descrizione': descrizione,
      if (dipendente != null) 'dipendente': dipendente,
    });
  }

  StoricoCompanion copyWith(
      {Value<int>? id,
      Value<String>? data,
      Value<String>? descrizione,
      Value<int>? dipendente}) {
    return StoricoCompanion(
      id: id ?? this.id,
      data: data ?? this.data,
      descrizione: descrizione ?? this.descrizione,
      dipendente: dipendente ?? this.dipendente,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (data.present) {
      map['data'] = Variable<String>(data.value);
    }
    if (descrizione.present) {
      map['descrizione'] = Variable<String>(descrizione.value);
    }
    if (dipendente.present) {
      map['dipendente'] = Variable<int>(dipendente.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('StoricoCompanion(')
          ..write('id: $id, ')
          ..write('data: $data, ')
          ..write('descrizione: $descrizione, ')
          ..write('dipendente: $dipendente')
          ..write(')'))
        .toString();
  }
}

class Storico extends Table with TableInfo<Storico, StoricoData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  Storico(this.attachedDatabase, [this._alias]);
  final VerificationMeta _idMeta = const VerificationMeta('id');
  late final GeneratedColumn<int?> id = GeneratedColumn<int?>(
      'id', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: false,
      $customConstraints: 'NOT NULL PRIMARY KEY AUTOINCREMENT');
  final VerificationMeta _dataMeta = const VerificationMeta('data');
  late final GeneratedColumn<String?> data = GeneratedColumn<String?>(
      'data', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _descrizioneMeta =
      const VerificationMeta('descrizione');
  late final GeneratedColumn<String?> descrizione = GeneratedColumn<String?>(
      'descrizione', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _dipendenteMeta = const VerificationMeta('dipendente');
  late final GeneratedColumn<int?> dipendente = GeneratedColumn<int?>(
      'dipendente', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  @override
  List<GeneratedColumn> get $columns => [id, data, descrizione, dipendente];
  @override
  String get aliasedName => _alias ?? 'storico';
  @override
  String get actualTableName => 'storico';
  @override
  VerificationContext validateIntegrity(Insertable<StoricoData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data')) {
      context.handle(
          _dataMeta, this.data.isAcceptableOrUnknown(data['data']!, _dataMeta));
    } else if (isInserting) {
      context.missing(_dataMeta);
    }
    if (data.containsKey('descrizione')) {
      context.handle(
          _descrizioneMeta,
          descrizione.isAcceptableOrUnknown(
              data['descrizione']!, _descrizioneMeta));
    } else if (isInserting) {
      context.missing(_descrizioneMeta);
    }
    if (data.containsKey('dipendente')) {
      context.handle(
          _dipendenteMeta,
          dipendente.isAcceptableOrUnknown(
              data['dipendente']!, _dipendenteMeta));
    } else if (isInserting) {
      context.missing(_dipendenteMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  StoricoData map(Map<String, dynamic> data, {String? tablePrefix}) {
    return StoricoData.fromData(data,
        prefix: tablePrefix != null ? '$tablePrefix.' : null);
  }

  @override
  Storico createAlias(String alias) {
    return Storico(attachedDatabase, alias);
  }

  @override
  List<String> get customConstraints => const [
        'FOREIGN KEY(dipendente) REFERENCES dipendente(id) ON UPDATE CASCADE ON DELETE NO ACTION'
      ];
  @override
  bool get dontWriteConstraints => true;
}

class MensileData extends DataClass implements Insertable<MensileData> {
  final int id;
  final int mese;
  final int anno;
  final int ore;
  final int pezzi;
  final int montaggi;
  final int visite;
  final int controlli;
  final String tipo;
  final String grado;
  final String ruolo;
  final int gruppo;
  final String? commenti;
  final int dipendente;
  final int dataInserimento;
  MensileData(
      {required this.id,
      required this.mese,
      required this.anno,
      required this.ore,
      required this.pezzi,
      required this.montaggi,
      required this.visite,
      required this.controlli,
      required this.tipo,
      required this.grado,
      required this.ruolo,
      required this.gruppo,
      this.commenti,
      required this.dipendente,
      required this.dataInserimento});
  factory MensileData.fromData(Map<String, dynamic> data, {String? prefix}) {
    final effectivePrefix = prefix ?? '';
    return MensileData(
      id: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}id'])!,
      mese: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}mese'])!,
      anno: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}anno'])!,
      ore: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}ore'])!,
      pezzi: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}pezzi'])!,
      montaggi: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}montaggi'])!,
      visite: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}visite'])!,
      controlli: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}controlli'])!,
      tipo: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}tipo'])!,
      grado: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}grado'])!,
      ruolo: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}ruolo'])!,
      gruppo: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}gruppo'])!,
      commenti: const StringType()
          .mapFromDatabaseResponse(data['${effectivePrefix}commenti']),
      dipendente: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}dipendente'])!,
      dataInserimento: const IntType()
          .mapFromDatabaseResponse(data['${effectivePrefix}data_inserimento'])!,
    );
  }
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['mese'] = Variable<int>(mese);
    map['anno'] = Variable<int>(anno);
    map['ore'] = Variable<int>(ore);
    map['pezzi'] = Variable<int>(pezzi);
    map['montaggi'] = Variable<int>(montaggi);
    map['visite'] = Variable<int>(visite);
    map['controlli'] = Variable<int>(controlli);
    map['tipo'] = Variable<String>(tipo);
    map['grado'] = Variable<String>(grado);
    map['ruolo'] = Variable<String>(ruolo);
    map['gruppo'] = Variable<int>(gruppo);
    if (!nullToAbsent || commenti != null) {
      map['commenti'] = Variable<String?>(commenti);
    }
    map['dipendente'] = Variable<int>(dipendente);
    map['data_inserimento'] = Variable<int>(dataInserimento);
    return map;
  }

  MensileCompanion toCompanion(bool nullToAbsent) {
    return MensileCompanion(
      id: Value(id),
      mese: Value(mese),
      anno: Value(anno),
      ore: Value(ore),
      pezzi: Value(pezzi),
      montaggi: Value(montaggi),
      visite: Value(visite),
      controlli: Value(controlli),
      tipo: Value(tipo),
      grado: Value(grado),
      ruolo: Value(ruolo),
      gruppo: Value(gruppo),
      commenti: commenti == null && nullToAbsent
          ? const Value.absent()
          : Value(commenti),
      dipendente: Value(dipendente),
      dataInserimento: Value(dataInserimento),
    );
  }

  factory MensileData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MensileData(
      id: serializer.fromJson<int>(json['id']),
      mese: serializer.fromJson<int>(json['mese']),
      anno: serializer.fromJson<int>(json['anno']),
      ore: serializer.fromJson<int>(json['ore']),
      pezzi: serializer.fromJson<int>(json['pezzi']),
      montaggi: serializer.fromJson<int>(json['montaggi']),
      visite: serializer.fromJson<int>(json['visite']),
      controlli: serializer.fromJson<int>(json['controlli']),
      tipo: serializer.fromJson<String>(json['tipo']),
      grado: serializer.fromJson<String>(json['grado']),
      ruolo: serializer.fromJson<String>(json['ruolo']),
      gruppo: serializer.fromJson<int>(json['gruppo']),
      commenti: serializer.fromJson<String?>(json['commenti']),
      dipendente: serializer.fromJson<int>(json['dipendente']),
      dataInserimento: serializer.fromJson<int>(json['data_inserimento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'mese': serializer.toJson<int>(mese),
      'anno': serializer.toJson<int>(anno),
      'ore': serializer.toJson<int>(ore),
      'pezzi': serializer.toJson<int>(pezzi),
      'montaggi': serializer.toJson<int>(montaggi),
      'visite': serializer.toJson<int>(visite),
      'controlli': serializer.toJson<int>(controlli),
      'tipo': serializer.toJson<String>(tipo),
      'grado': serializer.toJson<String>(grado),
      'ruolo': serializer.toJson<String>(ruolo),
      'gruppo': serializer.toJson<int>(gruppo),
      'commenti': serializer.toJson<String?>(commenti),
      'dipendente': serializer.toJson<int>(dipendente),
      'data_inserimento': serializer.toJson<int>(dataInserimento),
    };
  }

  MensileData copyWith(
          {int? id,
          int? mese,
          int? anno,
          int? ore,
          int? pezzi,
          int? montaggi,
          int? visite,
          int? controlli,
          String? tipo,
          String? grado,
          String? ruolo,
          int? gruppo,
          String? commenti,
          int? dipendente,
          int? dataInserimento}) =>
      MensileData(
        id: id ?? this.id,
        mese: mese ?? this.mese,
        anno: anno ?? this.anno,
        ore: ore ?? this.ore,
        pezzi: pezzi ?? this.pezzi,
        montaggi: montaggi ?? this.montaggi,
        visite: visite ?? this.visite,
        controlli: controlli ?? this.controlli,
        tipo: tipo ?? this.tipo,
        grado: grado ?? this.grado,
        ruolo: ruolo ?? this.ruolo,
        gruppo: gruppo ?? this.gruppo,
        commenti: commenti ?? this.commenti,
        dipendente: dipendente ?? this.dipendente,
        dataInserimento: dataInserimento ?? this.dataInserimento,
      );
  @override
  String toString() {
    return (StringBuffer('MensileData(')
          ..write('id: $id, ')
          ..write('mese: $mese, ')
          ..write('anno: $anno, ')
          ..write('ore: $ore, ')
          ..write('pezzi: $pezzi, ')
          ..write('montaggi: $montaggi, ')
          ..write('visite: $visite, ')
          ..write('controlli: $controlli, ')
          ..write('tipo: $tipo, ')
          ..write('grado: $grado, ')
          ..write('ruolo: $ruolo, ')
          ..write('gruppo: $gruppo, ')
          ..write('commenti: $commenti, ')
          ..write('dipendente: $dipendente, ')
          ..write('dataInserimento: $dataInserimento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      mese,
      anno,
      ore,
      pezzi,
      montaggi,
      visite,
      controlli,
      tipo,
      grado,
      ruolo,
      gruppo,
      commenti,
      dipendente,
      dataInserimento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MensileData &&
          other.id == this.id &&
          other.mese == this.mese &&
          other.anno == this.anno &&
          other.ore == this.ore &&
          other.pezzi == this.pezzi &&
          other.montaggi == this.montaggi &&
          other.visite == this.visite &&
          other.controlli == this.controlli &&
          other.tipo == this.tipo &&
          other.grado == this.grado &&
          other.ruolo == this.ruolo &&
          other.gruppo == this.gruppo &&
          other.commenti == this.commenti &&
          other.dipendente == this.dipendente &&
          other.dataInserimento == this.dataInserimento);
}

class MensileCompanion extends UpdateCompanion<MensileData> {
  final Value<int> id;
  final Value<int> mese;
  final Value<int> anno;
  final Value<int> ore;
  final Value<int> pezzi;
  final Value<int> montaggi;
  final Value<int> visite;
  final Value<int> controlli;
  final Value<String> tipo;
  final Value<String> grado;
  final Value<String> ruolo;
  final Value<int> gruppo;
  final Value<String?> commenti;
  final Value<int> dipendente;
  final Value<int> dataInserimento;
  const MensileCompanion({
    this.id = const Value.absent(),
    this.mese = const Value.absent(),
    this.anno = const Value.absent(),
    this.ore = const Value.absent(),
    this.pezzi = const Value.absent(),
    this.montaggi = const Value.absent(),
    this.visite = const Value.absent(),
    this.controlli = const Value.absent(),
    this.tipo = const Value.absent(),
    this.grado = const Value.absent(),
    this.ruolo = const Value.absent(),
    this.gruppo = const Value.absent(),
    this.commenti = const Value.absent(),
    this.dipendente = const Value.absent(),
    this.dataInserimento = const Value.absent(),
  });
  MensileCompanion.insert({
    this.id = const Value.absent(),
    required int mese,
    required int anno,
    required int ore,
    required int pezzi,
    required int montaggi,
    required int visite,
    required int controlli,
    required String tipo,
    required String grado,
    required String ruolo,
    required int gruppo,
    this.commenti = const Value.absent(),
    required int dipendente,
    required int dataInserimento,
  })  : mese = Value(mese),
        anno = Value(anno),
        ore = Value(ore),
        pezzi = Value(pezzi),
        montaggi = Value(montaggi),
        visite = Value(visite),
        controlli = Value(controlli),
        tipo = Value(tipo),
        grado = Value(grado),
        ruolo = Value(ruolo),
        gruppo = Value(gruppo),
        dipendente = Value(dipendente),
        dataInserimento = Value(dataInserimento);
  static Insertable<MensileData> custom({
    Expression<int>? id,
    Expression<int>? mese,
    Expression<int>? anno,
    Expression<int>? ore,
    Expression<int>? pezzi,
    Expression<int>? montaggi,
    Expression<int>? visite,
    Expression<int>? controlli,
    Expression<String>? tipo,
    Expression<String>? grado,
    Expression<String>? ruolo,
    Expression<int>? gruppo,
    Expression<String?>? commenti,
    Expression<int>? dipendente,
    Expression<int>? dataInserimento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (mese != null) 'mese': mese,
      if (anno != null) 'anno': anno,
      if (ore != null) 'ore': ore,
      if (pezzi != null) 'pezzi': pezzi,
      if (montaggi != null) 'montaggi': montaggi,
      if (visite != null) 'visite': visite,
      if (controlli != null) 'controlli': controlli,
      if (tipo != null) 'tipo': tipo,
      if (grado != null) 'grado': grado,
      if (ruolo != null) 'ruolo': ruolo,
      if (gruppo != null) 'gruppo': gruppo,
      if (commenti != null) 'commenti': commenti,
      if (dipendente != null) 'dipendente': dipendente,
      if (dataInserimento != null) 'data_inserimento': dataInserimento,
    });
  }

  MensileCompanion copyWith(
      {Value<int>? id,
      Value<int>? mese,
      Value<int>? anno,
      Value<int>? ore,
      Value<int>? pezzi,
      Value<int>? montaggi,
      Value<int>? visite,
      Value<int>? controlli,
      Value<String>? tipo,
      Value<String>? grado,
      Value<String>? ruolo,
      Value<int>? gruppo,
      Value<String?>? commenti,
      Value<int>? dipendente,
      Value<int>? dataInserimento}) {
    return MensileCompanion(
      id: id ?? this.id,
      mese: mese ?? this.mese,
      anno: anno ?? this.anno,
      ore: ore ?? this.ore,
      pezzi: pezzi ?? this.pezzi,
      montaggi: montaggi ?? this.montaggi,
      visite: visite ?? this.visite,
      controlli: controlli ?? this.controlli,
      tipo: tipo ?? this.tipo,
      grado: grado ?? this.grado,
      ruolo: ruolo ?? this.ruolo,
      gruppo: gruppo ?? this.gruppo,
      commenti: commenti ?? this.commenti,
      dipendente: dipendente ?? this.dipendente,
      dataInserimento: dataInserimento ?? this.dataInserimento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (mese.present) {
      map['mese'] = Variable<int>(mese.value);
    }
    if (anno.present) {
      map['anno'] = Variable<int>(anno.value);
    }
    if (ore.present) {
      map['ore'] = Variable<int>(ore.value);
    }
    if (pezzi.present) {
      map['pezzi'] = Variable<int>(pezzi.value);
    }
    if (montaggi.present) {
      map['montaggi'] = Variable<int>(montaggi.value);
    }
    if (visite.present) {
      map['visite'] = Variable<int>(visite.value);
    }
    if (controlli.present) {
      map['controlli'] = Variable<int>(controlli.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (grado.present) {
      map['grado'] = Variable<String>(grado.value);
    }
    if (ruolo.present) {
      map['ruolo'] = Variable<String>(ruolo.value);
    }
    if (gruppo.present) {
      map['gruppo'] = Variable<int>(gruppo.value);
    }
    if (commenti.present) {
      map['commenti'] = Variable<String?>(commenti.value);
    }
    if (dipendente.present) {
      map['dipendente'] = Variable<int>(dipendente.value);
    }
    if (dataInserimento.present) {
      map['data_inserimento'] = Variable<int>(dataInserimento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MensileCompanion(')
          ..write('id: $id, ')
          ..write('mese: $mese, ')
          ..write('anno: $anno, ')
          ..write('ore: $ore, ')
          ..write('pezzi: $pezzi, ')
          ..write('montaggi: $montaggi, ')
          ..write('visite: $visite, ')
          ..write('controlli: $controlli, ')
          ..write('tipo: $tipo, ')
          ..write('grado: $grado, ')
          ..write('ruolo: $ruolo, ')
          ..write('gruppo: $gruppo, ')
          ..write('commenti: $commenti, ')
          ..write('dipendente: $dipendente, ')
          ..write('dataInserimento: $dataInserimento')
          ..write(')'))
        .toString();
  }
}

class Mensile extends Table with TableInfo<Mensile, MensileData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  Mensile(this.attachedDatabase, [this._alias]);
  final VerificationMeta _idMeta = const VerificationMeta('id');
  late final GeneratedColumn<int?> id = GeneratedColumn<int?>(
      'id', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: false,
      $customConstraints: 'NOT NULL PRIMARY KEY AUTOINCREMENT');
  final VerificationMeta _meseMeta = const VerificationMeta('mese');
  late final GeneratedColumn<int?> mese = GeneratedColumn<int?>(
      'mese', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _annoMeta = const VerificationMeta('anno');
  late final GeneratedColumn<int?> anno = GeneratedColumn<int?>(
      'anno', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _oreMeta = const VerificationMeta('ore');
  late final GeneratedColumn<int?> ore = GeneratedColumn<int?>(
      'ore', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _pezziMeta = const VerificationMeta('pezzi');
  late final GeneratedColumn<int?> pezzi = GeneratedColumn<int?>(
      'pezzi', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _montaggiMeta = const VerificationMeta('montaggi');
  late final GeneratedColumn<int?> montaggi = GeneratedColumn<int?>(
      'montaggi', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _visiteMeta = const VerificationMeta('visite');
  late final GeneratedColumn<int?> visite = GeneratedColumn<int?>(
      'visite', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _controlliMeta = const VerificationMeta('controlli');
  late final GeneratedColumn<int?> controlli = GeneratedColumn<int?>(
      'controlli', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  late final GeneratedColumn<String?> tipo = GeneratedColumn<String?>(
      'tipo', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _gradoMeta = const VerificationMeta('grado');
  late final GeneratedColumn<String?> grado = GeneratedColumn<String?>(
      'grado', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _ruoloMeta = const VerificationMeta('ruolo');
  late final GeneratedColumn<String?> ruolo = GeneratedColumn<String?>(
      'ruolo', aliasedName, false,
      type: const StringType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _gruppoMeta = const VerificationMeta('gruppo');
  late final GeneratedColumn<int?> gruppo = GeneratedColumn<int?>(
      'gruppo', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _commentiMeta = const VerificationMeta('commenti');
  late final GeneratedColumn<String?> commenti = GeneratedColumn<String?>(
      'commenti', aliasedName, true,
      type: const StringType(),
      requiredDuringInsert: false,
      $customConstraints: '');
  final VerificationMeta _dipendenteMeta = const VerificationMeta('dipendente');
  late final GeneratedColumn<int?> dipendente = GeneratedColumn<int?>(
      'dipendente', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  final VerificationMeta _dataInserimentoMeta =
      const VerificationMeta('dataInserimento');
  late final GeneratedColumn<int?> dataInserimento = GeneratedColumn<int?>(
      'data_inserimento', aliasedName, false,
      type: const IntType(),
      requiredDuringInsert: true,
      $customConstraints: 'NOT NULL');
  @override
  List<GeneratedColumn> get $columns => [
        id,
        mese,
        anno,
        ore,
        pezzi,
        montaggi,
        visite,
        controlli,
        tipo,
        grado,
        ruolo,
        gruppo,
        commenti,
        dipendente,
        dataInserimento
      ];
  @override
  String get aliasedName => _alias ?? 'mensile';
  @override
  String get actualTableName => 'mensile';
  @override
  VerificationContext validateIntegrity(Insertable<MensileData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('mese')) {
      context.handle(
          _meseMeta, mese.isAcceptableOrUnknown(data['mese']!, _meseMeta));
    } else if (isInserting) {
      context.missing(_meseMeta);
    }
    if (data.containsKey('anno')) {
      context.handle(
          _annoMeta, anno.isAcceptableOrUnknown(data['anno']!, _annoMeta));
    } else if (isInserting) {
      context.missing(_annoMeta);
    }
    if (data.containsKey('ore')) {
      context.handle(
          _oreMeta, ore.isAcceptableOrUnknown(data['ore']!, _oreMeta));
    } else if (isInserting) {
      context.missing(_oreMeta);
    }
    if (data.containsKey('pezzi')) {
      context.handle(
          _pezziMeta, pezzi.isAcceptableOrUnknown(data['pezzi']!, _pezziMeta));
    } else if (isInserting) {
      context.missing(_pezziMeta);
    }
    if (data.containsKey('montaggi')) {
      context.handle(_montaggiMeta,
          montaggi.isAcceptableOrUnknown(data['montaggi']!, _montaggiMeta));
    } else if (isInserting) {
      context.missing(_montaggiMeta);
    }
    if (data.containsKey('visite')) {
      context.handle(_visiteMeta,
          visite.isAcceptableOrUnknown(data['visite']!, _visiteMeta));
    } else if (isInserting) {
      context.missing(_visiteMeta);
    }
    if (data.containsKey('controlli')) {
      context.handle(_controlliMeta,
          controlli.isAcceptableOrUnknown(data['controlli']!, _controlliMeta));
    } else if (isInserting) {
      context.missing(_controlliMeta);
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    } else if (isInserting) {
      context.missing(_tipoMeta);
    }
    if (data.containsKey('grado')) {
      context.handle(
          _gradoMeta, grado.isAcceptableOrUnknown(data['grado']!, _gradoMeta));
    } else if (isInserting) {
      context.missing(_gradoMeta);
    }
    if (data.containsKey('ruolo')) {
      context.handle(
          _ruoloMeta, ruolo.isAcceptableOrUnknown(data['ruolo']!, _ruoloMeta));
    } else if (isInserting) {
      context.missing(_ruoloMeta);
    }
    if (data.containsKey('gruppo')) {
      context.handle(_gruppoMeta,
          gruppo.isAcceptableOrUnknown(data['gruppo']!, _gruppoMeta));
    } else if (isInserting) {
      context.missing(_gruppoMeta);
    }
    if (data.containsKey('commenti')) {
      context.handle(_commentiMeta,
          commenti.isAcceptableOrUnknown(data['commenti']!, _commentiMeta));
    }
    if (data.containsKey('dipendente')) {
      context.handle(
          _dipendenteMeta,
          dipendente.isAcceptableOrUnknown(
              data['dipendente']!, _dipendenteMeta));
    } else if (isInserting) {
      context.missing(_dipendenteMeta);
    }
    if (data.containsKey('data_inserimento')) {
      context.handle(
          _dataInserimentoMeta,
          dataInserimento.isAcceptableOrUnknown(
              data['data_inserimento']!, _dataInserimentoMeta));
    } else if (isInserting) {
      context.missing(_dataInserimentoMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MensileData map(Map<String, dynamic> data, {String? tablePrefix}) {
    return MensileData.fromData(data,
        prefix: tablePrefix != null ? '$tablePrefix.' : null);
  }

  @override
  Mensile createAlias(String alias) {
    return Mensile(attachedDatabase, alias);
  }

  @override
  List<String> get customConstraints => const [
        'FOREIGN KEY(dipendente) REFERENCES dipendente(id) ON UPDATE CASCADE ON DELETE NO ACTION'
      ];
  @override
  bool get dontWriteConstraints => true;
}

abstract class _$AppDb extends GeneratedDatabase {
  _$AppDb(QueryExecutor e) : super(SqlTypeSystem.defaultInstance, e);
  late final Gruppo gruppo = Gruppo(this);
  late final Tipo tipo = Tipo(this);
  late final Grado grado = Grado(this);
  late final Ruolo ruolo = Ruolo(this);
  late final Dipendente dipendente = Dipendente(this);
  late final Storico storico = Storico(this);
  late final Mensile mensile = Mensile(this);
  Future<int> prepareTipo() {
    return customInsert(
      'INSERT INTO tipo VALUES(\'TipoU = Produttore Avanzato\'),(\'TipoAP = Produttore Standard\')',
      variables: [],
      updates: {tipo},
    );
  }

  Future<int> prepareGrado() {
    return customInsert(
      'INSERT INTO grado VALUES(\'A\'),(\'B\'),(\'C\'),(\'D\')',
      variables: [],
      updates: {grado},
    );
  }

  Future<int> prepareRuolo() {
    return customInsert(
      'INSERT INTO ruolo VALUES(\'PI = Nessun obiettivo\'),(\'PA = Obiettivo 1 mese\'),(\'PR = Obiettivo regolare\'),(\'IR = Irregolare\'),(\'IN = Inattivo\'),(\'DC = Disattivato\'),(\'TR = Trasferito\')',
      variables: [],
      updates: {ruolo},
    );
  }

  Selectable<TipoData> getEveryTipo() {
    return customSelect('SELECT valore FROM tipo', variables: [], readsFrom: {
      tipo,
    }).map(tipo.mapFromRow);
  }

  Selectable<GradoData> getEveryGrado() {
    return customSelect('SELECT valore FROM grado', variables: [], readsFrom: {
      grado,
    }).map(grado.mapFromRow);
  }

  Selectable<RuoloData> getEveryRuolo() {
    return customSelect('SELECT valore FROM ruolo', variables: [], readsFrom: {
      ruolo,
    }).map(ruolo.mapFromRow);
  }

  Selectable<GetEveryNomeGruppoResult> getEveryNomeGruppo() {
    return customSelect('SELECT id, nome FROM gruppo',
        variables: [],
        readsFrom: {
          gruppo,
        }).map((QueryRow row) {
      return GetEveryNomeGruppoResult(
        id: row.read<int>('id'),
        nome: row.read<String>('nome'),
      );
    });
  }

  Selectable<int?> getNextAutoincrementID() {
    return customSelect('SELECT MAX(id) FROM gruppo',
        variables: [],
        readsFrom: {
          gruppo,
        }).map((QueryRow row) => row.read<int?>('MAX(id)'));
  }

  Selectable<GruppoData> getEveryGruppo() {
    return customSelect('SELECT * FROM gruppo', variables: [], readsFrom: {
      gruppo,
    }).map(gruppo.mapFromRow);
  }

  Selectable<DipendenteData> getEveryDipendente() {
    return customSelect('SELECT * FROM dipendente', variables: [], readsFrom: {
      dipendente,
    }).map(dipendente.mapFromRow);
  }

  Selectable<GruppoData> getGruppoFromID(int id) {
    return customSelect('SELECT * FROM gruppo WHERE id = :id', variables: [
      Variable<int>(id)
    ], readsFrom: {
      gruppo,
    }).map(gruppo.mapFromRow);
  }

  Selectable<DipendenteData> getDipendenteFromID(int id) {
    return customSelect('SELECT * FROM dipendente WHERE id = :id', variables: [
      Variable<int>(id)
    ], readsFrom: {
      dipendente,
    }).map(dipendente.mapFromRow);
  }

  Selectable<GetDipendentiMensiliResult> getDipendentiMensili() {
    return customSelect(
        'SELECT id, nome, cognome, tipo, grado, ruolo, gruppo FROM dipendente WHERE ruolo IN (\'PI = Nessun obiettivo\', \'PA = Obiettivo 1 mese\', \'PR = Obiettivo regolare\', \'IR = Irregolare\') ORDER BY cognome ASC',
        variables: [],
        readsFrom: {
          dipendente,
        }).map((QueryRow row) {
      return GetDipendentiMensiliResult(
        id: row.read<int>('id'),
        nome: row.read<String>('nome'),
        cognome: row.read<String>('cognome'),
        tipo: row.read<String>('tipo'),
        grado: row.read<String>('grado'),
        ruolo: row.read<String>('ruolo'),
        gruppo: row.read<int>('gruppo'),
      );
    });
  }

  Selectable<int> getDipendentiConvalidati(int mese, int anno) {
    return customSelect(
        'SELECT dipendente FROM mensile WHERE mese = :mese AND anno = :anno',
        variables: [
          Variable<int>(mese),
          Variable<int>(anno)
        ],
        readsFrom: {
          mensile,
        }).map((QueryRow row) => row.read<int>('dipendente'));
  }

  Selectable<GetDipendentiConvalidatiForDropdownResult>
      getDipendentiConvalidatiForDropdown(int mese, int anno) {
    return customSelect(
        'SELECT id, nome, cognome FROM dipendente WHERE id IN (SELECT dipendente FROM mensile WHERE mese = :mese AND anno = :anno)',
        variables: [
          Variable<int>(mese),
          Variable<int>(anno)
        ],
        readsFrom: {
          dipendente,
          mensile,
        }).map((QueryRow row) {
      return GetDipendentiConvalidatiForDropdownResult(
        id: row.read<int>('id'),
        nome: row.read<String>('nome'),
        cognome: row.read<String>('cognome'),
      );
    });
  }

  Selectable<MensileData> getDipendentiConvalidatiData(int mese, int anno) {
    return customSelect(
        'SELECT * FROM mensile WHERE mese = :mese AND anno = :anno ORDER BY dipendente ASC',
        variables: [
          Variable<int>(mese),
          Variable<int>(anno)
        ],
        readsFrom: {
          mensile,
        }).map(mensile.mapFromRow);
  }

  Selectable<int> getNextDipendente(int mese, int anno) {
    return customSelect(
        'SELECT dipendente FROM mensile WHERE mese = :mese AND anno = :anno ORDER BY data_inserimento DESC LIMIT 1',
        variables: [
          Variable<int>(mese),
          Variable<int>(anno)
        ],
        readsFrom: {
          mensile,
        }).map((QueryRow row) => row.read<int>('dipendente'));
  }

  Selectable<int> getMensile(int dipendente, int anno, int mese) {
    return customSelect(
        'SELECT id FROM mensile WHERE dipendente = :dipendente AND anno = :anno AND mese = :mese',
        variables: [
          Variable<int>(dipendente),
          Variable<int>(anno),
          Variable<int>(mese)
        ],
        readsFrom: {
          mensile,
        }).map((QueryRow row) => row.read<int>('id'));
  }

  Selectable<DipendenteData> hasDipendenteChangedThisMonth(
      int id, String tipo, String grado, String ruolo, int gruppo) {
    return customSelect(
        'SELECT * FROM dipendente WHERE id = :id AND tipo = :tipo AND grado = :grado AND ruolo = :ruolo AND gruppo = :gruppo',
        variables: [
          Variable<int>(id),
          Variable<String>(tipo),
          Variable<String>(grado),
          Variable<String>(ruolo),
          Variable<int>(gruppo)
        ],
        readsFrom: {
          dipendente,
        }).map(dipendente.mapFromRow);
  }

  Selectable<GetListaMensileResult> getListaMensile(
      int anno, int mese, String ruolo, String gruppo) {
    return customSelect(
        'SELECT dipendente.nome, dipendente.cognome, mensile.ruolo, mensile.gruppo, pezzi, montaggi, ore, controlli, visite FROM mensile INNER JOIN dipendente ON mensile.dipendente = dipendente.id WHERE anno = :anno AND mese = :mese AND (mensile.ruolo LIKE :ruolo AND mensile.gruppo LIKE :gruppo)',
        variables: [
          Variable<int>(anno),
          Variable<int>(mese),
          Variable<String>(ruolo),
          Variable<String>(gruppo)
        ],
        readsFrom: {
          dipendente,
          mensile,
        }).map((QueryRow row) {
      return GetListaMensileResult(
        nome: row.read<String>('nome'),
        cognome: row.read<String>('cognome'),
        ruolo: row.read<String>('ruolo'),
        gruppo: row.read<int>('gruppo'),
        pezzi: row.read<int>('pezzi'),
        montaggi: row.read<int>('montaggi'),
        ore: row.read<int>('ore'),
        controlli: row.read<int>('controlli'),
        visite: row.read<int>('visite'),
      );
    });
  }

  Selectable<GetTotaleMensileResult> getTotaleMensile(int anno, int mese) {
    return customSelect(
        'SELECT ruolo, SUM(pezzi) AS pezzi, SUM(montaggi) AS montaggi, SUM(ore) AS ore, SUM(controlli) AS controlli, SUM(visite) AS visite, COUNT(dipendente) AS dipendente FROM mensile WHERE anno = :anno AND mese = :mese GROUP BY ruolo',
        variables: [
          Variable<int>(anno),
          Variable<int>(mese)
        ],
        readsFrom: {
          mensile,
        }).map((QueryRow row) {
      return GetTotaleMensileResult(
        ruolo: row.read<String>('ruolo'),
        pezzi: row.read<int>('pezzi'),
        montaggi: row.read<int>('montaggi'),
        ore: row.read<int>('ore'),
        controlli: row.read<int>('controlli'),
        visite: row.read<int>('visite'),
        dipendente: row.read<int>('dipendente'),
      );
    });
  }

  Selectable<GetRapportoAnnualeResult> getRapportoAnnuale(
      int anno, String ruolo, String gruppo) {
    return customSelect(
        'SELECT mese, anno, SUM(pezzi) AS pezzi, SUM(montaggi) AS montaggi, SUM(ore) AS ore, SUM(controlli) AS controlli, SUM(visite) AS visite FROM mensile WHERE (anno = :anno OR anno = :anno + 1) AND (mensile.ruolo LIKE :ruolo AND mensile.gruppo LIKE :gruppo) GROUP BY mese, anno',
        variables: [
          Variable<int>(anno),
          Variable<String>(ruolo),
          Variable<String>(gruppo)
        ],
        readsFrom: {
          mensile,
        }).map((QueryRow row) {
      return GetRapportoAnnualeResult(
        mese: row.read<int>('mese'),
        anno: row.read<int>('anno'),
        pezzi: row.read<int>('pezzi'),
        montaggi: row.read<int>('montaggi'),
        ore: row.read<int>('ore'),
        controlli: row.read<int>('controlli'),
        visite: row.read<int>('visite'),
      );
    });
  }

  Selectable<int> getEveryAvailableYear() {
    return customSelect('SELECT anno FROM mensile GROUP BY anno',
        variables: [],
        readsFrom: {
          mensile,
        }).map((QueryRow row) => row.read<int>('anno'));
  }

  Selectable<GetSingoloImpiegatoResult> getSingoloImpiegato(
      int singolo, String ruolo, String gruppo, int anno) {
    return customSelect(
        'SELECT m.mese, m.anno, SUM(m.pezzi) AS pezzi, SUM(m.montaggi) AS montaggi, SUM(m.ore) AS ore, SUM(m.controlli) AS controlli, SUM(m.visite) AS visite, SUM(m.pezzi + m.montaggi + m.ore + m.controlli + m.visite) AS tot, d.note FROM mensile m INNER JOIN dipendente d ON m.dipendente = d.id WHERE m.dipendente = :singolo AND (m.ruolo LIKE :ruolo AND m.gruppo LIKE :gruppo) AND (m.anno = :anno OR m.anno = :anno + 1) GROUP BY m.mese, m.anno',
        variables: [
          Variable<int>(singolo),
          Variable<String>(ruolo),
          Variable<String>(gruppo),
          Variable<int>(anno)
        ],
        readsFrom: {
          mensile,
          dipendente,
        }).map((QueryRow row) {
      return GetSingoloImpiegatoResult(
        mese: row.read<int>('mese'),
        anno: row.read<int>('anno'),
        pezzi: row.read<int>('pezzi'),
        montaggi: row.read<int>('montaggi'),
        ore: row.read<int>('ore'),
        controlli: row.read<int>('controlli'),
        visite: row.read<int>('visite'),
        tot: row.read<int>('tot'),
        note: row.read<String?>('note'),
      );
    });
  }

  Selectable<GetSingoloImpiegatoPDFResult> getSingoloImpiegatoPDF(
      int singolo, int anno) {
    return customSelect(
        'SELECT m.dipendente, m.mese, m.anno, SUM(m.pezzi) AS pezzi, SUM(m.montaggi) AS montaggi, SUM(m.ore) AS ore, SUM(m.controlli) AS controlli, SUM(m.visite) AS visite, SUM(m.pezzi + m.montaggi + m.ore + m.controlli + m.visite) AS tot, d.note FROM mensile m INNER JOIN dipendente d ON m.dipendente = d.id WHERE m.dipendente = :singolo AND (m.anno = :anno OR m.anno = :anno + 1) GROUP BY m.dipendente, m.mese, m.anno',
        variables: [
          Variable<int>(singolo),
          Variable<int>(anno)
        ],
        readsFrom: {
          mensile,
          dipendente,
        }).map((QueryRow row) {
      return GetSingoloImpiegatoPDFResult(
        dipendente: row.read<int>('dipendente'),
        mese: row.read<int>('mese'),
        anno: row.read<int>('anno'),
        pezzi: row.read<int>('pezzi'),
        montaggi: row.read<int>('montaggi'),
        ore: row.read<int>('ore'),
        controlli: row.read<int>('controlli'),
        visite: row.read<int>('visite'),
        tot: row.read<int>('tot'),
        note: row.read<String?>('note'),
      );
    });
  }

  Selectable<int> areThereValidatedUsers() {
    return customSelect('SELECT dipendente FROM mensile',
        variables: [],
        readsFrom: {
          mensile,
        }).map((QueryRow row) => row.read<int>('dipendente'));
  }

  Future<int> insertDipendente(
      String nome,
      String cognome,
      String sesso,
      String cellulare,
      String indirizzo,
      int CAP,
      String localita,
      String data_nascita,
      String data_affiliazione,
      String tipo,
      String grado,
      String ruolo,
      int gruppo,
      String? note) {
    return customInsert(
      'INSERT INTO dipendente (nome, cognome, sesso, cellulare, indirizzo, CAP, localita, data_nascita, data_affiliazione, tipo, grado, ruolo, gruppo, note) VALUES (:nome, :cognome, :sesso, :cellulare, :indirizzo, :CAP, :localita, :data_nascita, :data_affiliazione, :tipo, :grado, :ruolo, :gruppo, :note)',
      variables: [
        Variable<String>(nome),
        Variable<String>(cognome),
        Variable<String>(sesso),
        Variable<String>(cellulare),
        Variable<String>(indirizzo),
        Variable<int>(CAP),
        Variable<String>(localita),
        Variable<String>(data_nascita),
        Variable<String>(data_affiliazione),
        Variable<String>(tipo),
        Variable<String>(grado),
        Variable<String>(ruolo),
        Variable<int>(gruppo),
        Variable<String?>(note)
      ],
      updates: {dipendente},
    );
  }

  Future<int> insertGruppo(String nome, String descrizione) {
    return customInsert(
      'INSERT INTO gruppo (nome, descrizione) VALUES (:nome, :descrizione)',
      variables: [Variable<String>(nome), Variable<String>(descrizione)],
      updates: {gruppo},
    );
  }

  Future<int> insertStorico(String data, String descrizione, int dipendente) {
    return customInsert(
      'INSERT INTO storico (data, descrizione, dipendente) VALUES (:data, :descrizione, :dipendente)',
      variables: [
        Variable<String>(data),
        Variable<String>(descrizione),
        Variable<int>(dipendente)
      ],
      updates: {storico},
    );
  }

  Future<int> insertMensile(
      int mese,
      int anno,
      int ore,
      int pezzi,
      int montaggi,
      int visite,
      int controlli,
      String tipo,
      String grado,
      String ruolo,
      int gruppo,
      String? commenti,
      int dipendente,
      int data_inserimento) {
    return customInsert(
      'INSERT INTO mensile (mese, anno, ore, pezzi, montaggi, visite, controlli, tipo, grado, ruolo, gruppo, commenti, dipendente, data_inserimento) VALUES (:mese, :anno, :ore, :pezzi, :montaggi, :visite, :controlli, :tipo, :grado, :ruolo, :gruppo, :commenti, :dipendente, :data_inserimento)',
      variables: [
        Variable<int>(mese),
        Variable<int>(anno),
        Variable<int>(ore),
        Variable<int>(pezzi),
        Variable<int>(montaggi),
        Variable<int>(visite),
        Variable<int>(controlli),
        Variable<String>(tipo),
        Variable<String>(grado),
        Variable<String>(ruolo),
        Variable<int>(gruppo),
        Variable<String?>(commenti),
        Variable<int>(dipendente),
        Variable<int>(data_inserimento)
      ],
      updates: {mensile},
    );
  }

  Future<int> updateDipendente(
      String nome,
      String cognome,
      String sesso,
      String cellulare,
      String indirizzo,
      int CAP,
      String localita,
      String data_nascita,
      String data_affiliazione,
      String tipo,
      String grado,
      String ruolo,
      int gruppo,
      String? note,
      int id) {
    return customUpdate(
      'UPDATE dipendente SET nome = :nome, cognome = :cognome, sesso = :sesso, cellulare = :cellulare, indirizzo = :indirizzo, CAP = :CAP, localita = :localita, data_nascita = :data_nascita, data_affiliazione = :data_affiliazione, tipo = :tipo, grado = :grado, ruolo = :ruolo, gruppo = :gruppo, note = :note WHERE id = :id',
      variables: [
        Variable<String>(nome),
        Variable<String>(cognome),
        Variable<String>(sesso),
        Variable<String>(cellulare),
        Variable<String>(indirizzo),
        Variable<int>(CAP),
        Variable<String>(localita),
        Variable<String>(data_nascita),
        Variable<String>(data_affiliazione),
        Variable<String>(tipo),
        Variable<String>(grado),
        Variable<String>(ruolo),
        Variable<int>(gruppo),
        Variable<String?>(note),
        Variable<int>(id)
      ],
      updates: {dipendente},
      updateKind: UpdateKind.update,
    );
  }

  Future<int> updateGruppo(String nome, String descrizione, int id) {
    return customUpdate(
      'UPDATE gruppo SET nome = :nome, descrizione = :descrizione WHERE id = :id',
      variables: [
        Variable<String>(nome),
        Variable<String>(descrizione),
        Variable<int>(id)
      ],
      updates: {gruppo},
      updateKind: UpdateKind.update,
    );
  }

  Future<int> updateDipendenteFromMensile(
      String tipo, String grado, String ruolo, int gruppo, int id) {
    return customUpdate(
      'UPDATE dipendente SET tipo = :tipo, grado = :grado, ruolo = :ruolo, gruppo = :gruppo WHERE id = :id',
      variables: [
        Variable<String>(tipo),
        Variable<String>(grado),
        Variable<String>(ruolo),
        Variable<int>(gruppo),
        Variable<int>(id)
      ],
      updates: {dipendente},
      updateKind: UpdateKind.update,
    );
  }

  Future<int> updateMensile(
      int ore,
      int pezzi,
      int montaggi,
      int visite,
      int controlli,
      String tipo,
      String grado,
      String ruolo,
      int gruppo,
      String? commenti,
      int id) {
    return customUpdate(
      'UPDATE mensile SET ore = :ore, pezzi = :pezzi, montaggi = :montaggi, visite = :visite, controlli = :controlli, tipo = :tipo, grado = :grado, ruolo = :ruolo, gruppo = :gruppo, commenti = :commenti WHERE id = :id',
      variables: [
        Variable<int>(ore),
        Variable<int>(pezzi),
        Variable<int>(montaggi),
        Variable<int>(visite),
        Variable<int>(controlli),
        Variable<String>(tipo),
        Variable<String>(grado),
        Variable<String>(ruolo),
        Variable<int>(gruppo),
        Variable<String?>(commenti),
        Variable<int>(id)
      ],
      updates: {mensile},
      updateKind: UpdateKind.update,
    );
  }

  Future<int> deleteDipendente(int id) {
    return customUpdate(
      'DELETE FROM dipendente WHERE id = :id',
      variables: [Variable<int>(id)],
      updates: {dipendente},
      updateKind: UpdateKind.delete,
    );
  }

  Future<int> deleteGruppo(int id) {
    return customUpdate(
      'DELETE FROM gruppo WHERE id = :id',
      variables: [Variable<int>(id)],
      updates: {gruppo},
      updateKind: UpdateKind.delete,
    );
  }

  Future<int> deleteYearData(int anno, int mese_di_partenza) {
    return customUpdate(
      'DELETE FROM mensile WHERE (anno = :anno AND mese < :mese_di_partenza) OR (anno = (:anno - 1) AND mese >= :mese_di_partenza)',
      variables: [Variable<int>(anno), Variable<int>(mese_di_partenza)],
      updates: {mensile},
      updateKind: UpdateKind.delete,
    );
  }

  @override
  Iterable<TableInfo> get allTables => allSchemaEntities.whereType<TableInfo>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities =>
      [gruppo, tipo, grado, ruolo, dipendente, storico, mensile];
  @override
  StreamQueryUpdateRules get streamUpdateRules => const StreamQueryUpdateRules(
        [
          WritePropagation(
            on: TableUpdateQuery.onTableName('gruppo',
                limitUpdateKind: UpdateKind.update),
            result: [
              TableUpdate('dipendente', kind: UpdateKind.update),
            ],
          ),
          WritePropagation(
            on: TableUpdateQuery.onTableName('grado',
                limitUpdateKind: UpdateKind.update),
            result: [
              TableUpdate('dipendente', kind: UpdateKind.update),
            ],
          ),
          WritePropagation(
            on: TableUpdateQuery.onTableName('tipo',
                limitUpdateKind: UpdateKind.update),
            result: [
              TableUpdate('dipendente', kind: UpdateKind.update),
            ],
          ),
          WritePropagation(
            on: TableUpdateQuery.onTableName('ruolo',
                limitUpdateKind: UpdateKind.update),
            result: [
              TableUpdate('dipendente', kind: UpdateKind.update),
            ],
          ),
          WritePropagation(
            on: TableUpdateQuery.onTableName('dipendente',
                limitUpdateKind: UpdateKind.update),
            result: [
              TableUpdate('storico', kind: UpdateKind.update),
            ],
          ),
          WritePropagation(
            on: TableUpdateQuery.onTableName('dipendente',
                limitUpdateKind: UpdateKind.update),
            result: [
              TableUpdate('mensile', kind: UpdateKind.update),
            ],
          ),
        ],
      );
}

class GetEveryNomeGruppoResult {
  final int id;
  final String nome;
  GetEveryNomeGruppoResult({
    required this.id,
    required this.nome,
  });
}

class GetDipendentiMensiliResult {
  final int id;
  final String nome;
  final String cognome;
  final String tipo;
  final String grado;
  final String ruolo;
  final int gruppo;
  GetDipendentiMensiliResult({
    required this.id,
    required this.nome,
    required this.cognome,
    required this.tipo,
    required this.grado,
    required this.ruolo,
    required this.gruppo,
  });
}

class GetDipendentiConvalidatiForDropdownResult {
  final int id;
  final String nome;
  final String cognome;
  GetDipendentiConvalidatiForDropdownResult({
    required this.id,
    required this.nome,
    required this.cognome,
  });
}

class GetListaMensileResult {
  final String nome;
  final String cognome;
  final String ruolo;
  final int gruppo;
  final int pezzi;
  final int montaggi;
  final int ore;
  final int controlli;
  final int visite;
  GetListaMensileResult({
    required this.nome,
    required this.cognome,
    required this.ruolo,
    required this.gruppo,
    required this.pezzi,
    required this.montaggi,
    required this.ore,
    required this.controlli,
    required this.visite,
  });
}

class GetTotaleMensileResult {
  final String ruolo;
  final int pezzi;
  final int montaggi;
  final int ore;
  final int controlli;
  final int visite;
  final int dipendente;
  GetTotaleMensileResult({
    required this.ruolo,
    required this.pezzi,
    required this.montaggi,
    required this.ore,
    required this.controlli,
    required this.visite,
    required this.dipendente,
  });
}

class GetRapportoAnnualeResult {
  final int mese;
  final int anno;
  final int pezzi;
  final int montaggi;
  final int ore;
  final int controlli;
  final int visite;
  GetRapportoAnnualeResult({
    required this.mese,
    required this.anno,
    required this.pezzi,
    required this.montaggi,
    required this.ore,
    required this.controlli,
    required this.visite,
  });
}

class GetSingoloImpiegatoResult {
  final int mese;
  final int anno;
  final int pezzi;
  final int montaggi;
  final int ore;
  final int controlli;
  final int visite;
  final int tot;
  final String? note;
  GetSingoloImpiegatoResult({
    required this.mese,
    required this.anno,
    required this.pezzi,
    required this.montaggi,
    required this.ore,
    required this.controlli,
    required this.visite,
    required this.tot,
    this.note,
  });
}

class GetSingoloImpiegatoPDFResult {
  final int dipendente;
  final int mese;
  final int anno;
  final int pezzi;
  final int montaggi;
  final int ore;
  final int controlli;
  final int visite;
  final int tot;
  final String? note;
  GetSingoloImpiegatoPDFResult({
    required this.dipendente,
    required this.mese,
    required this.anno,
    required this.pezzi,
    required this.montaggi,
    required this.ore,
    required this.controlli,
    required this.visite,
    required this.tot,
    this.note,
  });
}
