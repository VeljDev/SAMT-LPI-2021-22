import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:track/templates/widgets.dart';

import '../../database/database.dart';

class ModifyValidatedData extends StatefulWidget {
  const ModifyValidatedData({Key? key}) : super(key: key);

  @override
  State<ModifyValidatedData> createState() => _ModifyValidatedDataState();
}

class _ModifyValidatedDataState extends State<ModifyValidatedData> {

  final _formKey = GlobalKey<FormState>();
  final _motivazioneKey = GlobalKey<FormState>();
  int? _dipendente;
  List<MensileData> datiConvalidati = [];
  List<GetDipendentiConvalidatiForDropdownResult> dipendentiConvalidati = [];

  final TextEditingController _ore = TextEditingController();
  final TextEditingController _pezzi = TextEditingController();
  final TextEditingController _montaggi = TextEditingController();
  final TextEditingController _visite = TextEditingController();
  final TextEditingController _controlli = TextEditingController();
  final TextEditingController _commenti = TextEditingController();
  final TextEditingController _motivazione = TextEditingController();
  String? _tipo;
  String? _grado;
  String? _ruolo;
  int? _gruppo;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((_) async {
      datiConvalidati = await Provider.of<AppDb>(context, listen: false).getDipendentiConvalidatiData(
        DateTime.now().month,
        DateTime.now().year
      ).get();
      dipendentiConvalidati = await Provider.of<AppDb>(context, listen: false).getDipendentiConvalidatiForDropdown(
          DateTime.now().month,
          DateTime.now().year
      ).get();

      if(datiConvalidati.isNotEmpty) {
        setState(() {
          _dipendente = datiConvalidati.first.dipendente;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar('Modifica dati convalidati'),
      body: Center(
        child: datiConvalidati.isNotEmpty && dipendentiConvalidati.isNotEmpty ? Container(
          margin: const EdgeInsets.symmetric(vertical: 15),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Dipendente:', style: labelTextStyle(),),
                    const SizedBox(
                      width: 20,
                    ),
                    DropdownButton(
                      items: dipendentiConvalidati.map((element) {
                        return DropdownMenuItem(
                          child: Text(element.nome + " " + element.cognome + " - " + element.id.toString()),
                          value: element.id,
                        );
                      }).toList(),
                      value: _dipendente,
                      onChanged: (int? value) {
                        setState(() {
                          _dipendente = value!;
                        });
                      },
                    ),
                  ],
                ),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci le ore',
                            labelText: 'Ore',
                          ),
                          controller: _ore..text = datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).ore.toString(),
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di ore non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i pezzi',
                            labelText: 'Pezzi',
                          ),
                          controller: _pezzi..text = datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).pezzi.toString(),
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di pezzi non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i montaggi',
                            labelText: 'Montaggi',
                          ),
                          controller: _montaggi..text = datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).montaggi.toString(),
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di montaggi non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci le visite',
                            labelText: 'Visite',
                          ),
                          controller: _visite..text = datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).visite.toString(),
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di visite non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i controlli',
                            labelText: 'Controlli',
                          ),
                          controller: _controlli..text = datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).controlli.toString(),
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di controlli non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i commenti (opzionale)',
                            labelText: 'Commenti',
                          ),
                          controller: _commenti..text = datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).commenti ?? '',
                          validator: (value) {
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryTipo().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<TipoData>> snapshot) {
                          if(snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il tipo:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.valore),
                                    value: element.valore,
                                  );
                                }).toList(),
                                value: datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).tipo,
                                onChanged: (String? value) { _tipo = value!; },
                                onSaved: (String? value) { _tipo = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            );
                          }

                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryGrado().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<GradoData>> snapshot) {
                          if(snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il grado:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.valore),
                                    value: element.valore,
                                  );
                                }).toList(),
                                value: datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).grado,
                                onChanged: (String? value) { _grado = value!; },
                                onSaved: (String? value) { _grado = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            );
                          }
                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryRuolo().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<RuoloData>> snapshot) {
                          if(snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il ruolo:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.valore),
                                    value: element.valore,
                                  );
                                }).toList(),
                                value: datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).ruolo,
                                onChanged: (String? value) { _ruolo = value!; },
                                onSaved: (String? value) { _ruolo = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            );
                          }
                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryNomeGruppo().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<GetEveryNomeGruppoResult>> snapshot) {
                          if(snapshot.hasData) {
                            return snapshot.data!.isNotEmpty ? SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il gruppo:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.nome),
                                    value: element.id,
                                  );
                                }).toList(),
                                value: datiConvalidati.singleWhere((e) => e.dipendente == _dipendente).gruppo,
                                onChanged: (int? value) { _gruppo = value!; },
                                onSaved: (int? value) { _gruppo = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            ) : const Text(
                              'Nessun gruppo disponibile',
                              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                            );
                          }
                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.green
                        ),
                        onPressed: () async {
                          if(_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            DipendenteData? hasDipendenteChanged = await Provider.of<AppDb>(context, listen: false).hasDipendenteChangedThisMonth(
                              _dipendente!,
                              _tipo!,
                              _grado!,
                              _ruolo!,
                              _gruppo!
                            ).getSingleOrNull();

                            int mensileID = await Provider.of<AppDb>(context, listen: false).getMensile(
                              _dipendente!,
                              DateTime.now().year,
                              DateTime.now().month
                            ).getSingle();

                            if(hasDipendenteChanged == null) {
                              await showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text('Motivazione'),
                                  content: Form(
                                    key: _motivazioneKey,
                                    child: TextFormField(
                                      decoration: const InputDecoration(
                                        border: UnderlineInputBorder(),
                                        hintText: 'Aggiungi una motivazione alle modifiche',
                                        labelText: 'Motivazione',
                                      ),
                                      controller: _motivazione,
                                      validator: (value) {
                                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                                      },
                                    ),
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () async {
                                        if(_motivazioneKey.currentState!.validate()) {
                                          await Provider.of<AppDb>(context, listen: false).insertStorico(
                                              DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now()),
                                              _motivazione.text,
                                              _dipendente!
                                          );
                                          await Provider.of<AppDb>(context, listen: false).updateDipendenteFromMensile(
                                              _tipo!,
                                              _grado!,
                                              _ruolo!,
                                              _gruppo!,
                                              _dipendente!
                                          );
                                          Navigator.pop(context);
                                        }
                                      },
                                      child: const Text('Salva'),
                                    ),
                                    TextButton(
                                      onPressed: () {
                                        Navigator.pop(context, 'Annulla');
                                      },
                                      child: const Text('Annulla'),
                                    ),
                                  ],
                                ),
                                barrierDismissible: false,
                              ).then((value) async {
                                if(value != null && value == 'Annulla') {
                                  return;
                                }
                                await Provider.of<AppDb>(context, listen: false).updateDipendenteFromMensile(
                                  _tipo!,
                                  _grado!,
                                  _ruolo!,
                                  _gruppo!,
                                  _dipendente!
                                );
                                await Provider.of<AppDb>(context, listen: false).updateMensile(
                                  int.tryParse(_ore.text)!,
                                  int.tryParse(_pezzi.text)!,
                                  int.tryParse(_montaggi.text)!,
                                  int.tryParse(_visite.text)!,
                                  int.tryParse(_controlli.text)!,
                                  _tipo!,
                                  _grado!,
                                  _ruolo!,
                                  _gruppo!,
                                  _commenti.text,
                                  mensileID
                                );
                                Navigator.pop(context);
                              });
                            }else {
                              await Provider.of<AppDb>(context, listen: false).updateMensile(
                                int.tryParse(_ore.text)!,
                                int.tryParse(_pezzi.text)!,
                                int.tryParse(_montaggi.text)!,
                                int.tryParse(_visite.text)!,
                                int.tryParse(_controlli.text)!,
                                _tipo!,
                                _grado!,
                                _ruolo!,
                                _gruppo!,
                                _commenti.text,
                                mensileID
                              );
                              Navigator.pop(context);
                            }
                          }
                        },
                        child: const Text('Salva e chiudi'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ) : Text('Nessun dato convalidato', style: titleTextStyle(),),
      ),
    );
  }
}
