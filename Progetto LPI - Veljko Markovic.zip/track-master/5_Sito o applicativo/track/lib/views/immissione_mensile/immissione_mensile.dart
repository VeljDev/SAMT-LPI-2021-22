import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:track/templates/widgets.dart';
import 'package:track/views/immissione_mensile/modifica_dati_convalidati.dart';

import '../../database/database.dart';

class ImmissioneMensile extends StatefulWidget {
  const ImmissioneMensile({Key? key}) : super(key: key);

  @override
  State<ImmissioneMensile> createState() => _ImmissioneMensileState();
}

class _ImmissioneMensileState extends State<ImmissioneMensile> {

  final _formKey = GlobalKey<FormState>();
  final _motivazioneKey = GlobalKey<FormState>();
  bool areThereUsers = true;
  List<GetDipendentiMensiliResult> dipendenti = [];
  List<int> dipendentiConvalidati = [];
  GetDipendentiMensiliResult?  currentDipendente;
  late String currentMonth;
  late String currentYear;
  final TextEditingController _ore = TextEditingController();
  final TextEditingController _pezzi = TextEditingController();
  final TextEditingController _montaggi = TextEditingController();
  final TextEditingController _visite = TextEditingController();
  final TextEditingController _controlli = TextEditingController();
  final TextEditingController _commenti = TextEditingController();
  final TextEditingController _motivazione = TextEditingController();
  String? _tipo;
  String? _grado;
  String? _ruolo;
  int? _gruppo;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((_) async {
      List<GetDipendentiMensiliResult> tempD = await loadDipendenti(context);
      List<int> tempC = await loadDipendentiConvalidati(context);
      int? tempN = await getNextDipendente(context);

      if(tempD.isEmpty) {
        setState(() {
          areThereUsers = false;
        });
        return;
      }

      if(tempD.length == tempC.length) {
        setState(() {
          dipendenti = [];
        });
        return;
      }

      setState(() {
        dipendenti = tempD;
        dipendentiConvalidati = tempC;

        if(tempN != null && tempN != dipendenti.last.id) {
          currentDipendente = dipendenti.elementAt(dipendenti.indexOf(dipendenti.singleWhere((element) => element.id == tempN)) + 1);
        }else {
          currentDipendente = dipendenti.first;
        }

        int index = dipendenti.indexOf(currentDipendente!);
        while(true) {
          if(dipendentiConvalidati.contains(currentDipendente!.id)) {
            index = index == dipendenti.length - 1 ? 0 : index + 1;
            currentDipendente = dipendenti.elementAt(index);
            continue;
          }
          break;
        }

        for(int convalidato in dipendentiConvalidati) {
          dipendenti.removeWhere((dipendente) => dipendente.id == convalidato);
        }
      });
    });
  }

  // Ritorno tutti i dipendenti registrati nel DB.
  Future<List<GetDipendentiMensiliResult>> loadDipendenti(context) async {
    return await Provider.of<AppDb>(context, listen: false).getDipendentiMensili().get();
  }

  // Ritorno tutti i dipendente convalidati nel DB.
  Future<List<int>> loadDipendentiConvalidati(context) async {
    return await Provider.of<AppDb>(context, listen: false).getDipendentiConvalidati(
        DateTime.now().month,
        DateTime.now().year
    ).get();
  }

  // Ritorno l'ultimo dipendente convalidato nel DB.
  Future<int?> getNextDipendente(context) async {
    return await Provider.of<AppDb>(context, listen: false).getNextDipendente(DateTime.now().month, DateTime.now().year).getSingleOrNull();
  }

  // Ritorno il titolo contenente i dati del dipendente formattato.
  String getTitle() {
    return currentDipendente != null ?
            currentDipendente!.cognome + " " + currentDipendente!.nome + " - " + currentDipendente!.id.toString() :
            '';
  }

  // Rimuove il dipendente convalidato dalla lista dei dipendente e procede
  // al dipendente successivo.
  void nextDipendente(bool convalida) {
    int temp = dipendenti.indexOf(currentDipendente!);

    if(currentDipendente != dipendenti.last) {
      currentDipendente = dipendenti[temp + 1];
    }else {
      currentDipendente = dipendenti.first;
    }

    convalida ? dipendenti.removeAt(temp) : null;
    setState(() { });
  }

  // Pulisco gli input del form.
  void _clearForm() {
    _ore.clear();
    _pezzi.clear();
    _montaggi.clear();
    _visite.clear();
    _controlli.clear();
    _commenti.clear();
  }

  @override
  Widget build(BuildContext context) {
    currentMonth = DateFormat.MMMM().format(DateTime.now());
    currentYear = DateFormat.y().format(DateTime.now());
    return Scaffold(
      appBar: AppBar(
        title: const Text('Immissione mensile'),
        actions: <Widget>[
          Container(
            margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 20),
            child: Text(currentMonth + ' ' + currentYear, style: subtitleTextStyle(),)
          )
        ],
      ),
      body: Center(
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 10),
          child: areThereUsers ? SingleChildScrollView(
            child: Column(
              children: [
                dipendenti.isEmpty ? Text('Mese già completato', style: titleTextStyle(),) : Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(getTitle(), style: titleTextStyle(),),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci le ore',
                            labelText: 'Ore',
                          ),
                          controller: _ore,
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di ore non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i pezzi',
                            labelText: 'Pezzi',
                          ),
                          controller: _pezzi,
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di pezzi non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i montaggi',
                            labelText: 'Montaggi',
                          ),
                          controller: _montaggi,
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di montaggi non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci le visite',
                            labelText: 'Visite',
                          ),
                          controller: _visite,
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di visite non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i controlli',
                            labelText: 'Controlli',
                          ),
                          controller: _controlli,
                          validator: (value) {
                            if(value == null || value.isEmpty) {
                              return 'Il campo non può essere vuoto!';
                            }
                            if(int.tryParse(value) == null) {
                              return 'Numero di controlli non valido';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.2,
                        child: TextFormField(
                          decoration: const InputDecoration(
                            border: UnderlineInputBorder(),
                            hintText: 'Inserisci i commenti (opzionale)',
                            labelText: 'Commenti',
                          ),
                          controller: _commenti,
                          validator: (value) {
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryTipo().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<TipoData>> snapshot) {
                          if(snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il tipo:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.valore),
                                    value: element.valore,
                                  );
                                }).toList(),
                                value: currentDipendente!.tipo,
                                onChanged: (String? value) { _tipo = value!; },
                                onSaved: (String? value) { _tipo = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            );
                          }

                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryGrado().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<GradoData>> snapshot) {
                          if(snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il grado:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.valore),
                                    value: element.valore,
                                  );
                                }).toList(),
                                value: currentDipendente!.grado,
                                onChanged: (String? value) { _grado = value!; },
                                onSaved: (String? value) { _grado = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            );
                          }
                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryRuolo().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<RuoloData>> snapshot) {
                          if(snapshot.hasData) {
                            return SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il ruolo:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.valore),
                                    value: element.valore,
                                  );
                                }).toList(),
                                value: currentDipendente!.ruolo,
                                onChanged: (String? value) { _ruolo = value!; },
                                onSaved: (String? value) { _ruolo = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            );
                          }
                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      StreamBuilder(
                        stream: Provider.of<AppDb>(context).getEveryNomeGruppo().watch(),
                        builder: (BuildContext context, AsyncSnapshot<List<GetEveryNomeGruppoResult>> snapshot) {
                          if(snapshot.hasData) {
                            return snapshot.data!.isNotEmpty ? SizedBox(
                              width: MediaQuery.of(context).size.width * 0.2,
                              child: DropdownButtonFormField(
                                decoration: InputDecoration(
                                    label: Text('Seleziona il gruppo:', style: labelTextStyle(),)
                                ),
                                items: snapshot.data!.map((element) {
                                  return DropdownMenuItem(
                                    child: Text(element.nome),
                                    value: element.id,
                                  );
                                }).toList(),
                                value: currentDipendente!.gruppo,
                                onChanged: (int? value) { _gruppo = value!; },
                                onSaved: (int? value) { _gruppo = value!; },
                                validator: (value) {
                                  return value != null ? null : 'Il campo non può essere vuoto!';
                                },
                              ),
                            ) : const Text(
                              'Nessun gruppo disponibile',
                              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                            );
                          }
                          return const CircularProgressIndicator();
                        },
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Colors.green
                            ),
                            onPressed: () async {
                              if(_formKey.currentState!.validate()) {
                                _formKey.currentState!.save();
                                DipendenteData? hasDipendenteChanged = await Provider.of<AppDb>(context, listen: false).hasDipendenteChangedThisMonth(
                                  currentDipendente!.id,
                                  _tipo!,
                                  _grado!,
                                  _ruolo!,
                                  _gruppo!
                                ).getSingleOrNull();

                                if(hasDipendenteChanged == null) {
                                  await showDialog(
                                    context: context,
                                    builder: (context) => AlertDialog(
                                      title: const Text('Motivazione'),
                                      content: Form(
                                        key: _motivazioneKey,
                                        child: TextFormField(
                                          decoration: const InputDecoration(
                                            border: UnderlineInputBorder(),
                                            hintText: 'Aggiungi una motivazione alle modifiche',
                                            labelText: 'Motivazione',
                                          ),
                                          controller: _motivazione,
                                          validator: (value) {
                                            return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                                          },
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () async {
                                            if(_motivazioneKey.currentState!.validate()) {
                                              await Provider.of<AppDb>(context, listen: false).insertStorico(
                                                DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now()),
                                                _motivazione.text,
                                                currentDipendente!.id
                                              );
                                              await Provider.of<AppDb>(context, listen: false).updateDipendenteFromMensile(
                                                _tipo!,
                                                _grado!,
                                                _ruolo!,
                                                _gruppo!,
                                                currentDipendente!.id
                                              );
                                              Navigator.pop(context);
                                            }
                                          },
                                          child: const Text('Salva'),
                                        ),
                                        TextButton(
                                          onPressed: () {
                                            Navigator.pop(context, 'Annulla');
                                          },
                                          child: const Text('Annulla'),
                                        ),
                                      ],
                                    ),
                                    barrierDismissible: false,
                                  ).then((value) async {
                                    if(value != null && value == 'Annulla') {
                                      return;
                                    }
                                    await Provider.of<AppDb>(context, listen: false).insertMensile(
                                      DateTime.now().month,
                                      DateTime.now().year,
                                      int.tryParse(_ore.text)!,
                                      int.tryParse(_pezzi.text)!,
                                      int.tryParse(_montaggi.text)!,
                                      int.tryParse(_visite.text)!,
                                      int.tryParse(_controlli.text)!,
                                      _tipo!,
                                      _grado!,
                                      _ruolo!,
                                      _gruppo!,
                                      _commenti.text,
                                      currentDipendente!.id,
                                      (DateTime.now().millisecondsSinceEpoch/1000).floor()
                                    );
                                    _clearForm();
                                    nextDipendente(true);
                                  });
                                }else {
                                  await Provider.of<AppDb>(context, listen: false).insertMensile(
                                    DateTime.now().month,
                                    DateTime.now().year,
                                    int.tryParse(_ore.text)!,
                                    int.tryParse(_pezzi.text)!,
                                    int.tryParse(_montaggi.text)!,
                                    int.tryParse(_visite.text)!,
                                    int.tryParse(_controlli.text)!,
                                    _tipo!,
                                    _grado!,
                                    _ruolo!,
                                    _gruppo!,
                                    _commenti.text,
                                    currentDipendente!.id,
                                    (DateTime.now().millisecondsSinceEpoch/1000).floor()
                                  );
                                  _clearForm();
                                  nextDipendente(true);
                                }
                              }
                            },
                            child: const Text('Convalida'),
                          ),
                          const SizedBox(
                            width: 50,
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Colors.blue
                            ),
                            onPressed: () {
                              _clearForm();
                              nextDipendente(false);
                            },
                            child: const Text('Prossimo'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.grey
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ModifyValidatedData()
                        )
                    );
                  },
                  child: const Text('Modifica dati convalidati'),
                ),
              ],
            ),
          ) : Text('Non ci sono utenti disponibili', style: titleTextStyle(),),
        ),
      ),
    );
  }
}