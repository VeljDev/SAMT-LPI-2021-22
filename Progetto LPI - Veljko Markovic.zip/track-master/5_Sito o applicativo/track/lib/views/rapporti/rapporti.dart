import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:collection/collection.dart';
import 'package:track/templates/widgets.dart';
import 'dart:io';
import 'package:pdf/widgets.dart' as pw;
import 'package:path/path.dart' as p;

import '../../database/database.dart';
import '../../templates/constants.dart';

class Rapporti extends StatefulWidget {
  const Rapporti({Key? key}) : super(key: key);

  @override
  State<Rapporti> createState() => _RapportiState();
}

class _RapportiState extends State<Rapporti> {

  List<DipendenteData> dipendenti = [];
  bool? anyValidatedUsers;
  List<int> anni = [];
  List<int> gruppi = [0];
  List<String> ruoli = ['%'];
  final ScrollController _scrollController = ScrollController();
  int _rapporto = 0;
  int _meseDiPartenza = meseDiPartenza;
  int? _currentDipendente;
  int? _currentYear;
  int? filtroGruppo;
  String? filtroRuolo;

  // Verifica che il mese sia valido. In caso contrario, ritorna il mese di
  // default definito nelle costanti.
  int getValidMonth(String month) {
    int? temp = int.tryParse(month);

    if(temp == null || (temp < 1 || temp > 12)) {
      return meseDiPartenza;
    }

    return temp;
  }

  // Leggo i dati contenuti nel file settings.json riguardanti il mese
  // di partenza.
  Future<void> loadSettings() async {
    var data = await rootBundle.loadString('assets/config/settings.json');
    var property = json.decode(data)['mese_di_partenza'];
    setState(() => _meseDiPartenza = getValidMonth(property.toString()));
  }

  // Ritorno tutti i dipendenti salvati nel DB.
  Future<void> loadDipendenti() async {
    dipendenti = await Provider.of<AppDb>(context, listen: false).getEveryDipendente().get();
    dipendenti.sort((a, b) => a.id.compareTo(b.id));
    setState(() {
      _currentDipendente = dipendenti.isNotEmpty ? dipendenti.first.id : null;
    });
  }

  // Ritorno tutti gli anni salvati nel DB.
  Future<void> loadAnni() async {
    anni = await Provider.of<AppDb>(context, listen: false).getEveryAvailableYear().get();
    setState(() {
      _currentYear = anni.isEmpty ? null : anni.last;
    });
  }

  // Indica se ci sono utenti convalidati
  Future<void> areThereAnyValidatedUsers() async {
    List temp = await Provider.of<AppDb>(context, listen: false).areThereValidatedUsers().get();
    setState(() {
      anyValidatedUsers = temp.isEmpty ? null : true;
    });
  }

  // Ritorno tutti i gruppi salvati nel DB.
  Future<void> loadGruppi() async {
    List<GruppoData> temp = await Provider.of<AppDb>(context, listen: false).getEveryGruppo().get();
    gruppi.addAll(temp.map((e) => e.id).toList());
    setState(() {
      filtroGruppo = gruppi.first;
    });
  }

  // Ritorno tutti i ruoli salvati nel DB.
  Future<void> loadRuoli() async {
    List<RuoloData> temp = await Provider.of<AppDb>(context, listen: false).getEveryRuolo().get();
    ruoli.addAll(temp.map((e) => e.valore).toList());
    setState(() {
      filtroRuolo = ruoli.first;
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((_) async {
      await loadSettings();
      await loadDipendenti();
      await loadAnni();
      await areThereAnyValidatedUsers();
      await loadGruppi();
      await loadRuoli();
    });
  }

  // Ritorna uno stream contenente il singolo impiegato.
  Stream<List<GetSingoloImpiegatoResult>> getSingoloImpiegatoStream(int? id) {
    return Provider.of<AppDb>(context).getSingoloImpiegato(
      id ?? _currentDipendente!,
      filtroRuolo!,
      filtroGruppo! == 0 ? '%' : filtroGruppo.toString(),
      DateTime.now().year
    ).watch();
  }
  // Ritorna uno stream contenente il la lista mensile.
  Stream<List<GetListaMensileResult>> getListaMensileStream() {
    return Provider.of<AppDb>(context).getListaMensile(
      DateTime.now().year,
      DateTime.now().month,
      filtroRuolo!,
      filtroGruppo! == 0 ? '%' : filtroGruppo.toString(),
    ).watch();
  }

  // Ritorna uno stream contenente il rapporto annuale.
  Stream<List<GetRapportoAnnualeResult>> getRapportoAnnualeStream() {
    return Provider.of<AppDb>(context).getRapportoAnnuale(
      _currentYear ?? 0,
      filtroRuolo!,
      filtroGruppo! == 0 ? '%' : filtroGruppo.toString(),
    ).watch();
  }

  Widget filtri() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text('Filtro ruolo:', style: labelTextStyle(),),
        const SizedBox(
          width: 20,
        ),
        DropdownButton(
          items: ruoli.map((element) {
            return DropdownMenuItem(
              child: Text(element != '%' ? element : 'Tutti'),
              value: element,
            );
          }).toList(),
          value: filtroRuolo,
          onChanged: (String? value) {
            setState(() {
              filtroRuolo = value;
            });
          },
        ),
        Text('Filtro gruppo:', style: labelTextStyle(),),
        const SizedBox(
          width: 20,
        ),
        DropdownButton(
          items: gruppi.map((element) {
            return DropdownMenuItem(
              child: Text(element != 0 ? element.toString() : 'Tutti'),
              value: element,
            );
          }).toList(),
          value: filtroGruppo,
          onChanged: (int? value) {
            setState(() {
              filtroGruppo = value;
            });
          },
        ),
      ],
    );
  }

  // In base alla scelta dell'utente, mostro una determinata tabella.
  Widget showReport() {
    if(_rapporto == 0) {
      return StreamBuilder(
        stream: getSingoloImpiegatoStream(null),
        builder: (BuildContext context, AsyncSnapshot<List<GetSingoloImpiegatoResult>> snapshot) {
          if(snapshot.hasData) {
            List<GetSingoloImpiegatoResult> records = snapshot.data!.where((e) => (e.anno == _currentYear && e.mese >= _meseDiPartenza) || (e.anno == _currentYear! + 1 && e.mese < _meseDiPartenza)).toList();

            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Dipendente:', style: labelTextStyle(),),
                    const SizedBox(
                      width: 20,
                    ),
                    DropdownButton(
                      items: dipendenti.map((element) {
                        return DropdownMenuItem(
                          child: Text(element.nome + " " + element.cognome + " - " + element.id.toString()),
                          value: element.id,
                        );
                      }).toList(),
                      value: _currentDipendente ?? dipendenti.first.id,
                      onChanged: (int? value) {
                        setState(() {
                          _currentDipendente = value!;
                        });
                      },
                    ),
                  ],
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.90,
                  child: Center(
                    child: Scrollbar(
                      isAlwaysShown: true,
                      scrollbarOrientation: ScrollbarOrientation.bottom,
                      controller: _scrollController,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        controller: _scrollController,
                        child: DataTable(
                          columns: [
                            DataColumn(label: Text('Mesi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Pezzi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Montaggi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Ore', style: headerTextStyle(),)),
                            DataColumn(label: Text('Controlli', style: headerTextStyle(),)),
                            DataColumn(label: Text('Visite', style: headerTextStyle(),)),
                            DataColumn(label: Text('Tot', style: headerTextStyle(),)),
                            DataColumn(label: Text('Note', style: headerTextStyle(),)),
                          ],
                          rows: records.map((e) {
                            return DataRow(
                              cells: <DataCell> [
                                DataCell(Text(DateFormat.MMMM().format(DateTime(_currentYear!, e.mese)))),
                                DataCell(Text(e.pezzi.toString())),
                                DataCell(Text(e.montaggi.toString())),
                                DataCell(Text(e.ore.toString())),
                                DataCell(Text(e.controlli.toString())),
                                DataCell(Text(e.visite.toString())),
                                DataCell(Text(e.tot.toString())),
                                DataCell(Text(e.note == null || e.note!.isEmpty ? '-' : e.note!))
                              ]
                            );
                          }).toList()..add(DataRow(
                            cells: <DataCell> [
                              DataCell(Text('Totali', style: headerTextStyle())),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.pezzi).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.montaggi).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.ore).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.controlli).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.visite).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.tot).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text('-', style: headerTextStyle(),))
                            ]
                          )),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          }

          return const CircularProgressIndicator();
        },
      );
    } else if (_rapporto == 1) {
      List<Widget> tables = [];
      List<DipendenteData> temp = dipendenti.sortedBy((element) => element.cognome);

      tables.add(filtri());

      for(var dipendente in temp) {
        tables.add(StreamBuilder(
          stream: getSingoloImpiegatoStream(dipendente.id),
          builder: (BuildContext context, AsyncSnapshot<List<GetSingoloImpiegatoResult>> snapshot) {
            if(snapshot.hasData) {
              List<GetSingoloImpiegatoResult> records = snapshot.data!.where((e) => (e.anno == _currentYear && e.mese >= _meseDiPartenza) || (e.anno == _currentYear! + 1 && e.mese < _meseDiPartenza)).toList();

              if(records.isEmpty) {
                return Container();
              }

              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 40,),
                  Text(dipendente.cognome + " " + dipendente.nome + " - " + dipendente.id.toString(), style: labelTextStyle(),),
                  const SizedBox(
                    width: 20,
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.90,
                    child: Center(
                      child: Scrollbar(
                        //isAlwaysShown: true,
                        scrollbarOrientation: ScrollbarOrientation.bottom,
                        controller: _scrollController,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          controller: _scrollController,
                          child: DataTable(
                            columns: [
                              DataColumn(label: Text('Mesi', style: headerTextStyle(),)),
                              DataColumn(label: Text('Pezzi', style: headerTextStyle(),)),
                              DataColumn(label: Text('Montaggi', style: headerTextStyle(),)),
                              DataColumn(label: Text('Ore', style: headerTextStyle(),)),
                              DataColumn(label: Text('Controlli', style: headerTextStyle(),)),
                              DataColumn(label: Text('Visite', style: headerTextStyle(),)),
                              DataColumn(label: Text('Tot', style: headerTextStyle(),)),
                              DataColumn(label: Text('Note', style: headerTextStyle(),)),
                            ],
                            rows: records.map((e) {
                              return DataRow(
                                cells: <DataCell> [
                                  DataCell(Text(DateFormat.MMMM().format(DateTime(_currentYear!, e.mese)))),
                                  DataCell(Text(e.pezzi.toString())),
                                  DataCell(Text(e.montaggi.toString())),
                                  DataCell(Text(e.ore.toString())),
                                  DataCell(Text(e.controlli.toString())),
                                  DataCell(Text(e.visite.toString())),
                                  DataCell(Text(e.tot.toString())),
                                  DataCell(Text(e.note == null || e.note!.isEmpty ? '-' : e.note!))
                                ]
                              );
                            }).toList()..add(DataRow(
                              cells: <DataCell> [
                                DataCell(Text('Totali', style: headerTextStyle())),
                                DataCell(Text(
                                  snapshot.data!.map((e) => e.pezzi).toList().sum.toString(),
                                  style: headerTextStyle(),
                                )),
                                DataCell(Text(
                                  snapshot.data!.map((e) => e.montaggi).toList().sum.toString(),
                                  style: headerTextStyle(),
                                )),
                                DataCell(Text(
                                  snapshot.data!.map((e) => e.ore).toList().sum.toString(),
                                  style: headerTextStyle(),
                                )),
                                DataCell(Text(
                                  snapshot.data!.map((e) => e.controlli).toList().sum.toString(),
                                  style: headerTextStyle(),
                                )),
                                DataCell(Text(
                                  snapshot.data!.map((e) => e.visite).toList().sum.toString(),
                                  style: headerTextStyle(),
                                )),
                                DataCell(Text(
                                  snapshot.data!.map((e) => e.tot).toList().sum.toString(),
                                  style: headerTextStyle(),
                                )),
                                DataCell(Text('-', style: headerTextStyle(),))
                              ]
                            )),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            }

            return const CircularProgressIndicator();
          },
        ));
      }

      return Column(
        children: tables,
      );
    } else if (_rapporto == 2) {
      return StreamBuilder(
        stream: getListaMensileStream(),
        builder: (BuildContext context, AsyncSnapshot<List<GetListaMensileResult>> snapshot) {
          if(snapshot.hasData && anyValidatedUsers != null) {
            return Column(
              children: [
                filtri(),
                snapshot.data!.isNotEmpty ? SizedBox(
                  width: MediaQuery.of(context).size.width * 0.90,
                  child: Center(
                    child: Scrollbar(
                      isAlwaysShown: true,
                      scrollbarOrientation: ScrollbarOrientation.bottom,
                      controller: _scrollController,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        controller: _scrollController,
                        child: DataTable(
                          columns: [
                            DataColumn(label: Text('Dipendente', style: headerTextStyle(),)),
                            DataColumn(label: Text('Ruolo', style: headerTextStyle(),)),
                            DataColumn(label: Text('Gruppo', style: headerTextStyle(),)),
                            DataColumn(label: Text('Pezzi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Montaggi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Ore', style: headerTextStyle(),)),
                            DataColumn(label: Text('Controlli', style: headerTextStyle(),)),
                            DataColumn(label: Text('Visite', style: headerTextStyle(),)),
                          ],
                          rows: snapshot.data!.map((e) {
                            return DataRow(
                              cells: <DataCell> [
                                DataCell(Text(e.cognome + ' ' + e.nome)),
                                DataCell(Text(e.ruolo)),
                                DataCell(Text(e.gruppo.toString())),
                                DataCell(Text(e.pezzi.toString())),
                                DataCell(Text(e.montaggi.toString())),
                                DataCell(Text(e.ore.toString())),
                                DataCell(Text(e.controlli.toString())),
                                DataCell(Text(e.visite.toString())),
                              ]
                            );
                          }).toList()..add(DataRow(
                            cells: <DataCell> [
                              DataCell(Text('Medie', style: headerTextStyle())),
                              DataCell(Text(
                                '-',
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                '-',
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.pezzi).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.montaggi).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.ore).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.controlli).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.visite).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                            ]
                          ))..add(DataRow(
                            cells: <DataCell> [
                              DataCell(Text('Totali', style: headerTextStyle())),
                              DataCell(Text(
                                '-',
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                '-',
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.pezzi).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.montaggi).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.ore).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.controlli).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                snapshot.data!.map((e) => e.visite).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                            ]
                          )),
                        ),
                      ),
                    ),
                  ),
                ) : Container(),
              ],
            );
          }

          return const CircularProgressIndicator();
        },
      );
    } else if (_rapporto == 3) {
      return StreamBuilder(
        stream: Provider.of<AppDb>(context).getTotaleMensile(DateTime.now().year, DateTime.now().month).watch(),
        builder: (BuildContext context, AsyncSnapshot<List<GetTotaleMensileResult>> snapshot) {
          if(snapshot.hasData && anyValidatedUsers != null) {
            return SizedBox(
              width: MediaQuery.of(context).size.width * 0.90,
              child: Center(
                child: Scrollbar(
                  isAlwaysShown: true,
                  scrollbarOrientation: ScrollbarOrientation.bottom,
                  controller: _scrollController,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    controller: _scrollController,
                    child: DataTable(
                      columns: [
                        DataColumn(label: Text('Ruoli', style: headerTextStyle(),)),
                        DataColumn(label: Text('Pezzi', style: headerTextStyle(),)),
                        DataColumn(label: Text('Montaggi', style: headerTextStyle(),)),
                        DataColumn(label: Text('Ore', style: headerTextStyle(),)),
                        DataColumn(label: Text('Controlli', style: headerTextStyle(),)),
                        DataColumn(label: Text('Visite', style: headerTextStyle(),)),
                        DataColumn(label: Text('Tot', style: headerTextStyle(),)),
                      ],
                      rows: snapshot.data!.map((e) {
                        return DataRow(
                          cells: <DataCell> [
                            DataCell(Text(e.ruolo)),
                            DataCell(Text(e.pezzi.toString())),
                            DataCell(Text(e.montaggi.toString())),
                            DataCell(Text(e.ore.toString())),
                            DataCell(Text(e.controlli.toString())),
                            DataCell(Text(e.visite.toString())),
                            DataCell(Text(e.dipendente.toString())),
                          ]
                        );
                      }).toList()..add(DataRow(
                          cells: <DataCell> [
                            DataCell(Text('Medie', style: headerTextStyle())),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.pezzi).toList().average.toStringAsFixed(0),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.montaggi).toList().average.toStringAsFixed(0),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.ore).toList().average.toStringAsFixed(0),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.controlli).toList().average.toStringAsFixed(0),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.visite).toList().average.toStringAsFixed(0),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.dipendente).toList().average.toStringAsFixed(0),
                              style: headerTextStyle(),
                            )),
                          ]
                      ))..add(DataRow(
                          cells: <DataCell> [
                            DataCell(Text('Totali', style: headerTextStyle(),)),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.pezzi).toList().sum.toString(),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.montaggi).toList().sum.toString(),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.ore).toList().sum.toString(),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.controlli).toList().sum.toString(),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.visite).toList().sum.toString(),
                              style: headerTextStyle(),
                            )),
                            DataCell(Text(
                              snapshot.data!.map((e) => e.dipendente).toList().sum.toString(),
                              style: headerTextStyle(),
                            )),
                          ]
                      )),
                    ),
                  ),
                ),
              ),
            );
          }

          return const CircularProgressIndicator();
        },
      );
    } else {
      return StreamBuilder(
        stream: getRapportoAnnualeStream(),
        builder: (BuildContext context, AsyncSnapshot<List<GetRapportoAnnualeResult>> snapshot) {
          if(snapshot.hasData && _currentYear != null) {
            if(anni.isEmpty) {
              return Text('Non ci sono anni disponibili', style: titleTextStyle(),);
            }

            List<GetRapportoAnnualeResult> records = snapshot.data!.where((e) => (e.anno == _currentYear && e.mese >= _meseDiPartenza) || (e.anno == _currentYear! + 1 && e.mese < _meseDiPartenza)).toList();

            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                filtri(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Anno:', style: labelTextStyle(),),
                    const SizedBox(
                      width: 20,
                    ),
                    DropdownButton(
                      items: anni.map((element) {
                        return DropdownMenuItem(
                          child: Text(element.toString()),
                          value: element,
                        );
                      }).toList(),
                      value: _currentYear ?? anni.first,
                      onChanged: (int? value) {
                        setState(() {
                          _currentYear = value!;
                        });
                      },
                    ),
                  ],
                ),
                records.isNotEmpty ? SizedBox(
                  width: MediaQuery.of(context).size.width * 0.90,
                  child: Center(
                    child: Scrollbar(
                      isAlwaysShown: true,
                      scrollbarOrientation: ScrollbarOrientation.bottom,
                      controller: _scrollController,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        controller: _scrollController,
                        child: DataTable(
                          columns: [
                            DataColumn(label: Text('Mesi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Pezzi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Montaggi', style: headerTextStyle(),)),
                            DataColumn(label: Text('Ore', style: headerTextStyle(),)),
                            DataColumn(label: Text('Controlli', style: headerTextStyle(),)),
                            DataColumn(label: Text('Visite', style: headerTextStyle(),)),
                          ],
                          rows: records.map((e) {
                            return DataRow(
                              cells: <DataCell> [
                                DataCell(Text(DateFormat.MMMM().format(DateTime(_currentYear!, e.mese)))),
                                DataCell(Text(e.pezzi.toString())),
                                DataCell(Text(e.montaggi.toString())),
                                DataCell(Text(e.ore.toString())),
                                DataCell(Text(e.controlli.toString())),
                                DataCell(Text(e.visite.toString())),
                              ]
                            );
                          }).toList()..add(DataRow(
                            cells: <DataCell> [
                              DataCell(Text('Medie', style: headerTextStyle())),
                              DataCell(Text(
                                records.map((e) => e.pezzi).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.montaggi).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.ore).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.controlli).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.visite).toList().average.toStringAsFixed(0),
                                style: headerTextStyle(),
                              )),
                            ]
                          ))..add(DataRow(
                            cells: <DataCell> [
                              DataCell(Text('Totali', style: headerTextStyle(),)),
                              DataCell(Text(
                                records.map((e) => e.pezzi).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.montaggi).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.ore).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.controlli).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                              DataCell(Text(
                                records.map((e) => e.visite).toList().sum.toString(),
                                style: headerTextStyle(),
                              )),
                            ]
                          )),
                        ),
                      ),
                    ),
                  ),
                ) : Container(),
              ],
            );
          }

          return const CircularProgressIndicator();
        },
      );
    }
  }

  // Mostro una serie di dialoghi che permettono di eliminare i dati di un anno.
  void _deleteYearData() async {
    int? tempYear = anni.isEmpty ? null : anni.first;
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Eliminazione dati annuali'),
        content: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Seleziona l\'anno dei dati da eliminare:'),
            const SizedBox(width: 10,),
            anni.isNotEmpty ? DropdownButton(
              items: anni.map((element) {
                return DropdownMenuItem(
                  child: Text(element.toString()),
                  value: element,
                );
              }).toList(),
              value: tempYear,
              onChanged: (int? value) {
                setState(() {
                  tempYear = value!;
                });
              },
            ) : const Text('Nessun anno disponibile')
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context, 'Sì');
            },
            child: const Text('Sì'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('No'),
          ),
        ],
      ),
      barrierDismissible: false
    ).then((value) async {
      if(value == 'Sì' && tempYear != null) {
        await showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Attenzione'),
            content: Text('Sei sicuro di voler eliminare per sempre i dati del ' + tempYear.toString() + '?'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context, 'Sì');
                },
                child: const Text('Sì'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('No'),
              ),
            ],
          ),
          barrierDismissible: false
        ).then((value) async {
          if(value == 'Sì') {
            await Provider.of<AppDb>(context, listen: false).deleteYearData(tempYear!, _meseDiPartenza);
            await areThereAnyValidatedUsers();
            await showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Eliminazione completata'),
                content: Text('I dati del ' + tempYear.toString() + ' sono stati eliminati con successo'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('OK'),
                  )
                ],
              ),
              barrierDismissible: false
            );
          }
        });
      }
    });
  }

  // Permette di creare un PDF e di salvarlo nella cartella Documenti
  // dell'utente.
  Future<void> _createPDF() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Row(
          children: const [
            Text('Caricando il PDF...'),
            CircularProgressIndicator()
          ],
        )
      ),
      barrierDismissible: false
    );

    List<GetSingoloImpiegatoPDFResult?> allImpiegati = [];
    List<GetListaMensileResult> listaMensile = await Provider.of<AppDb>(context, listen: false).getListaMensile(DateTime.now().year, DateTime.now().month, '%', '%').get();
    List<GetTotaleMensileResult> totaleMensile = await Provider.of<AppDb>(context, listen: false).getTotaleMensile(DateTime.now().year, DateTime.now().month).get();
    List<GetRapportoAnnualeResult> annuale = await Provider.of<AppDb>(context, listen: false).getRapportoAnnuale(_currentYear ?? DateTime.now().year, '%', '%').get();
    List<DipendenteData> temp = dipendenti.sortedBy((element) => element.cognome);

    for(var dipendente in temp) {
      allImpiegati.add(await Provider.of<AppDb>(context, listen: false).getSingoloImpiegatoPDF(dipendente.id, DateTime.now().year).getSingleOrNull());
    }

    final font = await PdfGoogleFonts.nunitoExtraLight();
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        orientation: pw.PageOrientation.landscape,
        build: (context) => [
         pw.Center(child: pw.Text('Rapporto ' + DateFormat('yyyy-MM-dd').format(DateTime.now()), style: pw.TextStyle(font: font, fontSize: 45),)),
         pw.SizedBox(height: 40),
         pw.Text('Tutti gli impiegati', style: pw.TextStyle(font: font, fontSize: 30)),
         pw.Table.fromTextArray(
           headerStyle: pw.TextStyle(font: font,),
           cellStyle: pw.TextStyle(font: font),
           data: <List<String>> [
             <String>['Dipendente', 'Mesi', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite', 'Tot', 'Note'],
             ...allImpiegati.map((e) {
               if(e == null) {
                 return ['-','-','-','-','-','-','-','-','-'];
               }

               DipendenteData tempDipendente = temp.singleWhere((element) => element.id == e.dipendente);

               return [
                 tempDipendente.cognome + ' ' + tempDipendente.nome,
                 DateFormat.MMMM().format(DateTime(DateTime.now().year, e.mese)),
                 e.pezzi.toString(),
                 e.montaggi.toString(),
                 e.ore.toString(),
                 e.controlli.toString(),
                 e.visite.toString(),
                 e.tot.toString(),
                 e.note == null || e.note!.isEmpty ? '-' : e.note!,
               ];
             }).toList(),
           ]
         ),
         pw.SizedBox(height: 40),
         pw.Text('Lista mensile dei valori degli impiegati', style: pw.TextStyle(font: font, fontSize: 30)),
         pw.Table.fromTextArray(
           headerStyle: pw.TextStyle(font: font),
           cellStyle: pw.TextStyle(font: font),
           data: <List<String>> [
             <String>['Dipendente', 'Ruolo', 'Gruppo', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite'],
             ...listaMensile.map((e) {
               return [
                 e.cognome + ' ' + e.nome,
                 e.ruolo,
                 e.gruppo.toString(),
                 e.pezzi.toString(),
                 e.montaggi.toString(),
                 e.ore.toString(),
                 e.controlli.toString(),
                 e.visite.toString()
               ];
             }).toList(),
             [
               'Medie',
               '-',
               '-',
               listaMensile.map((e) => e.pezzi).average.toStringAsFixed(0),
               listaMensile.map((e) => e.montaggi).average.toStringAsFixed(0),
               listaMensile.map((e) => e.ore).average.toStringAsFixed(0),
               listaMensile.map((e) => e.controlli).average.toStringAsFixed(0),
               listaMensile.map((e) => e.visite).average.toStringAsFixed(0),
             ],
             [
               'Totali',
               '-',
               '-',
               listaMensile.map((e) => e.pezzi).sum.toString(),
               listaMensile.map((e) => e.montaggi).sum.toString(),
               listaMensile.map((e) => e.ore).sum.toString(),
               listaMensile.map((e) => e.controlli).sum.toString(),
               listaMensile.map((e) => e.visite).sum.toString(),
             ],
           ]
         ),
         pw.SizedBox(height: 40),
         pw.Text('Totale mensile della somma di tutti i valori', style: pw.TextStyle(font: font, fontSize: 30)),
         pw.Table.fromTextArray(
           headerStyle: pw.TextStyle(font: font),
           cellStyle: pw.TextStyle(font: font),
           data: <List<String>> [
             <String>['Ruoli', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite', 'Tot'],
             ...totaleMensile.map((e) {
               return [
                 e.ruolo,
                 e.pezzi.toString(),
                 e.montaggi.toString(),
                 e.ore.toString(),
                 e.controlli.toString(),
                 e.visite.toString(),
                 e.dipendente.toString()
               ];
             }).toList(),
             [
               'Medie',
               totaleMensile.map((e) => e.pezzi).average.toStringAsFixed(0),
               totaleMensile.map((e) => e.montaggi).average.toStringAsFixed(0),
               totaleMensile.map((e) => e.ore).average.toStringAsFixed(0),
               totaleMensile.map((e) => e.controlli).average.toStringAsFixed(0),
               totaleMensile.map((e) => e.visite).average.toStringAsFixed(0),
               totaleMensile.map((e) => e.dipendente).average.toStringAsFixed(0),
             ],
             [
               'Totali',
               totaleMensile.map((e) => e.pezzi).sum.toString(),
               totaleMensile.map((e) => e.montaggi).sum.toString(),
               totaleMensile.map((e) => e.ore).sum.toString(),
               totaleMensile.map((e) => e.controlli).sum.toString(),
               totaleMensile.map((e) => e.visite).sum.toString(),
               totaleMensile.map((e) => e.dipendente).sum.toString(),
             ],
           ]
         ),
         pw.SizedBox(height: 40),
         pw.Text('Annuale con totale dei valori mensili', style: pw.TextStyle(font: font, fontSize: 30)),
         pw.Table.fromTextArray(
           headerStyle: pw.TextStyle(font: font),
           cellStyle: pw.TextStyle(font: font),
           data: <List<String>> [
             <String>['Mesi', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite'],
             ...annuale.map((e) {
               return [
                 DateFormat.MMMM().format(DateTime(DateTime.now().year, e.mese)),
                 e.pezzi.toString(),
                 e.montaggi.toString(),
                 e.ore.toString(),
                 e.controlli.toString(),
                 e.visite.toString()
               ];
             }).toList(),
             [
               'Medie',
               annuale.map((e) => e.pezzi).average.toStringAsFixed(0),
               annuale.map((e) => e.montaggi).average.toStringAsFixed(0),
               annuale.map((e) => e.ore).average.toStringAsFixed(0),
               annuale.map((e) => e.controlli).average.toStringAsFixed(0),
               annuale.map((e) => e.visite).average.toStringAsFixed(0),
             ],
             [
               'Totali',
               annuale.map((e) => e.pezzi).sum.toString(),
               annuale.map((e) => e.montaggi).sum.toString(),
               annuale.map((e) => e.ore).sum.toString(),
               annuale.map((e) => e.controlli).sum.toString(),
               annuale.map((e) => e.visite).sum.toString(),
             ],
           ]
         ),
        ],
      ),
    );

    final documents = await getApplicationDocumentsDirectory();
    final file = File(p.join(documents.path, 'Rapporto ' + DateFormat('yyyy-MM-dd').format(DateTime.now()) + '.pdf'));
    await file.writeAsBytes(await pdf.save());

    Navigator.of(context).pop();

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Esportazione completata'),
        content: Text('Il PDF è stato esportato con successo!\nPercorso: ' + file.path),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('OK'),
          )
        ],
      ),
      barrierDismissible: false
    );
  }

  // Permette di stampare i rapporti (esattamente come il PDF).
  Future<void> _print() async {
    List<GetSingoloImpiegatoPDFResult?> allImpiegati = [];
    List<GetListaMensileResult> listaMensile = await Provider.of<AppDb>(context, listen: false).getListaMensile(DateTime.now().year, DateTime.now().month, '%', '%').get();
    List<GetTotaleMensileResult> totaleMensile = await Provider.of<AppDb>(context, listen: false).getTotaleMensile(DateTime.now().year, DateTime.now().month).get();
    List<GetRapportoAnnualeResult> annuale = await Provider.of<AppDb>(context, listen: false).getRapportoAnnuale(_currentYear ?? DateTime.now().year, '%', '%').get();
    List<DipendenteData> temp = dipendenti.sortedBy((element) => element.cognome);

    for(var dipendente in temp) {
      allImpiegati.add(await Provider.of<AppDb>(context, listen: false).getSingoloImpiegatoPDF(dipendente.id, DateTime.now().year).getSingleOrNull());
    }

    final font = await PdfGoogleFonts.nunitoExtraLight();
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        orientation: pw.PageOrientation.landscape,
        build: (context) => [
          pw.Center(child: pw.Text('Rapporto ' + DateFormat('yyyy-MM-dd').format(DateTime.now()), style: pw.TextStyle(font: font, fontSize: 45),)),
          pw.SizedBox(height: 40),
          pw.Text('Tutti gli impiegati', style: pw.TextStyle(font: font, fontSize: 30)),
          pw.Table.fromTextArray(
            headerStyle: pw.TextStyle(font: font,),
            cellStyle: pw.TextStyle(font: font),
            data: <List<String>> [
              <String>['Dipendente', 'Mesi', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite', 'Tot', 'Note'],
              ...allImpiegati.map((e) {
                if(e == null) {
                  return ['-','-','-','-','-','-','-','-','-'];
                }

                DipendenteData tempDipendente = temp.singleWhere((element) => element.id == e.dipendente);

                return [
                  tempDipendente.cognome + ' ' + tempDipendente.nome,
                  DateFormat.MMMM().format(DateTime(DateTime.now().year, e.mese)),
                  e.pezzi.toString(),
                  e.montaggi.toString(),
                  e.ore.toString(),
                  e.controlli.toString(),
                  e.visite.toString(),
                  e.tot.toString(),
                  e.note == null || e.note!.isEmpty ? '-' : e.note!,
                ];
              }).toList(),
            ]
          ),
          pw.SizedBox(height: 40),
          pw.Text('Lista mensile dei valori degli impiegati', style: pw.TextStyle(font: font, fontSize: 30)),
          pw.Table.fromTextArray(
            headerStyle: pw.TextStyle(font: font),
            cellStyle: pw.TextStyle(font: font),
            data: <List<String>> [
              <String>['Dipendente', 'Ruolo', 'Gruppo', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite'],
              ...listaMensile.map((e) {
                return [
                  e.cognome + ' ' + e.nome,
                  e.ruolo,
                  e.gruppo.toString(),
                  e.pezzi.toString(),
                  e.montaggi.toString(),
                  e.ore.toString(),
                  e.controlli.toString(),
                  e.visite.toString()
                ];
              }).toList(),
              [
                'Medie',
                '-',
                '-',
                listaMensile.map((e) => e.pezzi).average.toStringAsFixed(0),
                listaMensile.map((e) => e.montaggi).average.toStringAsFixed(0),
                listaMensile.map((e) => e.ore).average.toStringAsFixed(0),
                listaMensile.map((e) => e.controlli).average.toStringAsFixed(0),
                listaMensile.map((e) => e.visite).average.toStringAsFixed(0),
              ],
              [
                'Totali',
                '-',
                '-',
                listaMensile.map((e) => e.pezzi).sum.toString(),
                listaMensile.map((e) => e.montaggi).sum.toString(),
                listaMensile.map((e) => e.ore).sum.toString(),
                listaMensile.map((e) => e.controlli).sum.toString(),
                listaMensile.map((e) => e.visite).sum.toString(),
              ],
            ]
          ),
          pw.SizedBox(height: 40),
          pw.Text('Totale mensile della somma di tutti i valori', style: pw.TextStyle(font: font, fontSize: 30)),
          pw.Table.fromTextArray(
            headerStyle: pw.TextStyle(font: font),
            cellStyle: pw.TextStyle(font: font),
            data: <List<String>> [
              <String>['Ruoli', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite', 'Tot'],
              ...totaleMensile.map((e) {
                return [
                  e.ruolo,
                  e.pezzi.toString(),
                  e.montaggi.toString(),
                  e.ore.toString(),
                  e.controlli.toString(),
                  e.visite.toString(),
                  e.dipendente.toString()
                ];
              }).toList(),
              [
                'Medie',
                totaleMensile.map((e) => e.pezzi).average.toStringAsFixed(0),
                totaleMensile.map((e) => e.montaggi).average.toStringAsFixed(0),
                totaleMensile.map((e) => e.ore).average.toStringAsFixed(0),
                totaleMensile.map((e) => e.controlli).average.toStringAsFixed(0),
                totaleMensile.map((e) => e.visite).average.toStringAsFixed(0),
                totaleMensile.map((e) => e.dipendente).average.toStringAsFixed(0),
              ],
              [
                'Totali',
                totaleMensile.map((e) => e.pezzi).sum.toString(),
                totaleMensile.map((e) => e.montaggi).sum.toString(),
                totaleMensile.map((e) => e.ore).sum.toString(),
                totaleMensile.map((e) => e.controlli).sum.toString(),
                totaleMensile.map((e) => e.visite).sum.toString(),
                totaleMensile.map((e) => e.dipendente).sum.toString(),
              ],
            ]
          ),
          pw.SizedBox(height: 40),
          pw.Text('Annuale con totale dei valori mensili', style: pw.TextStyle(font: font, fontSize: 30)),
          pw.Table.fromTextArray(
            headerStyle: pw.TextStyle(font: font),
            cellStyle: pw.TextStyle(font: font),
            data: <List<String>> [
              <String>['Mesi', 'Pezzi', 'Montaggi', 'Ore', 'Controlli', 'Visite'],
              ...annuale.map((e) {
                return [
                  DateFormat.MMMM().format(DateTime(DateTime.now().year, e.mese)),
                  e.pezzi.toString(),
                  e.montaggi.toString(),
                  e.ore.toString(),
                  e.controlli.toString(),
                  e.visite.toString()
                ];
              }).toList(),
              [
                'Medie',
                annuale.map((e) => e.pezzi).average.toStringAsFixed(0),
                annuale.map((e) => e.montaggi).average.toStringAsFixed(0),
                annuale.map((e) => e.ore).average.toStringAsFixed(0),
                annuale.map((e) => e.controlli).average.toStringAsFixed(0),
                annuale.map((e) => e.visite).average.toStringAsFixed(0),
              ],
              [
                'Totali',
                annuale.map((e) => e.pezzi).sum.toString(),
                annuale.map((e) => e.montaggi).sum.toString(),
                annuale.map((e) => e.ore).sum.toString(),
                annuale.map((e) => e.controlli).sum.toString(),
                annuale.map((e) => e.visite).sum.toString(),
              ],
            ]
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save()
    );
  }

  // Mostra un dialogo che indica che non ci sono dipendenti disponibili.
  Future<void> _noDipendentiDialog() async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Attenzione'),
        content: const Text('Non ci sono dipendenti disponibili'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          )
        ],
      ),
      barrierDismissible: false
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rapporti'),
        actions: <Widget>[
          InkWell(
            onTap: () {
              _deleteYearData();
            },
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: const [
                  Text('Elimina'),
                  SizedBox(
                    width: 3,
                  ),
                  Icon(Icons.delete_forever)
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              if(dipendenti.isNotEmpty && anyValidatedUsers != null) {
                _createPDF();
              }else {
                _noDipendentiDialog();
              }
            },
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: const [
                  Text('Esporta'),
                  SizedBox(
                    width: 3,
                  ),
                  Icon(Icons.picture_as_pdf)
                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              if(dipendenti.isNotEmpty && anyValidatedUsers != null) {
                _print();
              }else {
                _noDipendentiDialog();
              }
            },
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: const [
                  Text('Stampa'),
                  SizedBox(
                    width: 3,
                  ),
                  Icon(Icons.print)
                ],
              ),
            ),
          )
        ],
      ),
      body: Container(
        margin: const EdgeInsets.symmetric(vertical: 50),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Rapporto:', style: labelTextStyle(),),
                    const SizedBox(
                      width: 20,
                    ),
                    DropdownButton(
                      items: const [
                        DropdownMenuItem(child: Text(singoloImpiegato), value: 0,),
                        DropdownMenuItem(child: Text(tuttiImpiegati), value: 1,),
                        DropdownMenuItem(child: Text(listaMensileValoriImpiegati), value: 2,),
                        DropdownMenuItem(child: Text(totaleMensileDellaSomma), value: 3,),
                        DropdownMenuItem(child: Text(rapportoAnnuale), value: 4,),
                      ],
                      value: _rapporto,
                      onChanged: (int? value) {
                        _scrollController.hasClients ? _scrollController.jumpTo(0) : null;
                        setState(() => _rapporto = value!);
                      },
                    )
                  ],
                ),
                dipendenti.isEmpty ? Text('Non ci sono dipendenti disponibili', style: titleTextStyle(),) :
                filtroGruppo != null && filtroRuolo != null ? showReport() : const CircularProgressIndicator()
              ],
            ),
          ),
        ),
      ),
    );
  }
}