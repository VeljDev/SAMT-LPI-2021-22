import 'package:flutter/material.dart';
import 'package:track/templates/constants.dart';
import 'package:track/templates/widgets.dart';
import 'package:track/views/anagrafico_utenti/anagrafico_utenti.dart';
import 'package:track/views/immissione_mensile/immissione_mensile.dart';
import 'package:track/views/rapporti/rapporti.dart';

class MainMenu extends StatefulWidget {
  const MainMenu({Key? key}) : super(key: key);

  @override
  State<MainMenu> createState() => _MainMenuState();
}

class _MainMenuState extends State<MainMenu> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar(windowTitle),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Benvenuto su Track!',
              style: titleTextStyle(),
            ),
            const SizedBox(
              height: 100,
            ),
            Container(
              margin: const EdgeInsets.only(right: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const AnagraficoUtenti())
                      );
                    },
                    child: Column(
                      children: [
                        const Icon(
                          Icons.group,
                          size: 70,
                        ),
                        Text(
                          'Anagrafico utenti',
                          style: iconTextStyle(),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const ImmissioneMensile())
                      );
                    },
                    child: Column(
                      children: [
                        const Icon(
                          Icons.app_registration,
                          size: 70,
                        ),
                        Text(
                          'Immissione mensile',
                          style: iconTextStyle(),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 30,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const Rapporti())
                      );
                    },
                    child: Column(
                      children: [
                        const Icon(
                          Icons.table_chart,
                          size: 70,
                        ),
                        Text(
                          'Rapporti',
                          style: iconTextStyle(),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
