import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:track/templates/constants.dart';
import 'package:track/templates/widgets.dart';
import 'package:track/views/anagrafico_utenti/aggiunta_dipendente_gruppo.dart';
import 'package:track/views/anagrafico_utenti/gestione_dipendente_gruppo.dart';

import '../../database/database.dart';

class AnagraficoUtenti extends StatefulWidget {
  const AnagraficoUtenti({Key? key}) : super(key: key);

  @override
  State<AnagraficoUtenti> createState() => _AnagraficoUtentiState();
}

class _AnagraficoUtentiState extends State<AnagraficoUtenti> {

  String _dati = utenti;
  bool showUsers = true;
  ScrollController scrollControllerUtentiV = ScrollController();
  ScrollController scrollControllerUtentiH = ScrollController();
  ScrollController scrollControllerGruppiV = ScrollController();
  ScrollController scrollControllerGruppiH = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Anagrafico utenti'),
        actions: <Widget>[
          InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddUserOrGroup(addUser: showUsers))
              );
            },
            child: Container(
              margin: const EdgeInsets.only(right: 20),
              child: Row(
                children: [
                  Text('Aggiungi un ' + (showUsers ? 'utente' : 'gruppo')),
                  const SizedBox(
                    width: 10,
                  ),
                  const Icon(Icons.add_circle)
                ],
              ),
            ),
          )
        ],
      ),
      body: Container(
        margin: const EdgeInsets.symmetric(vertical: 50),
        child: Center(
            child: SingleChildScrollView(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text('Dati:', style: labelTextStyle(),),
                        const SizedBox(
                          width: 20,
                        ),
                        DropdownButton(
                          items: const [
                            DropdownMenuItem(child: Text(utenti), value: utenti,),
                            DropdownMenuItem(child: Text(gruppi), value: gruppi,),
                          ],
                          value: _dati,
                          onChanged: (String? value) {
                            setState(() {
                              _dati = value!;
                              showUsers = _dati == utenti ? true : false;
                            });
                          },
                        )
                      ],
                    ),
                    showUsers ? StreamBuilder(
                      stream: Provider.of<AppDb>(context).getEveryDipendente().watch(),
                      builder: (BuildContext context, AsyncSnapshot<List<DipendenteData>> snapshot) {
                        if(snapshot.hasData) {
                          return SizedBox(
                            width: MediaQuery.of(context).size.width * 0.90,
                            child: Center(
                              child: Scrollbar(
                                isAlwaysShown: true,
                                scrollbarOrientation: ScrollbarOrientation.bottom,
                                controller: scrollControllerUtentiH,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  controller: scrollControllerUtentiH,
                                  child: DataTable(
                                    showCheckboxColumn: false,
                                    columns: [
                                      DataColumn(label: Text(auID, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auNome, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auCognome, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auSesso, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auCellulare, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auIndirizzo, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auCAP, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auLocalita, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auDataNascita, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auDataAffiliazione, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auTipo, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auGrado, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auRuolo, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auGruppo, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auNote, style: headerTextStyle(),))
                                    ],
                                    rows: snapshot.data!.map((e) {
                                      return DataRow(
                                        onSelectChanged: (bool? selected) {
                                          if(selected != null && selected) {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(builder: (context) => ManageUserOrGroup(manageUser: showUsers, entityID: e.id,))
                                            );
                                          }
                                        },
                                        cells: <DataCell> [
                                          DataCell(Text(e.id.toString())),
                                          DataCell(Text(e.nome)),
                                          DataCell(Text(e.cognome)),
                                          DataCell(Text(e.sesso)),
                                          DataCell(Text(e.cellulare)),
                                          DataCell(Text(e.indirizzo)),
                                          DataCell(Text(e.cap.toString())),
                                          DataCell(Text(e.localita)),
                                          DataCell(Text(e.dataNascita)),
                                          DataCell(Text(e.dataAffiliazione)),
                                          DataCell(Text(e.tipo)),
                                          DataCell(Text(e.grado)),
                                          DataCell(Text(e.ruolo)),
                                          DataCell(Text(e.gruppo.toString())),
                                          DataCell(Text(e.note!.isEmpty ? '-' : e.note!)),
                                        ]
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }

                        return const CircularProgressIndicator();
                      },
                    ) : StreamBuilder(
                      stream: Provider.of<AppDb>(context).getEveryGruppo().watch(),
                      builder: (BuildContext context, AsyncSnapshot<List<GruppoData>> snapshot) {
                        if(snapshot.hasData) {
                          return SizedBox(
                            width: MediaQuery.of(context).size.width * 0.90,
                            child: Center(
                              child: Scrollbar(
                                isAlwaysShown: true,
                                scrollbarOrientation: ScrollbarOrientation.bottom,
                                controller: scrollControllerGruppiH,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  controller: scrollControllerGruppiH,
                                  child: DataTable(
                                    showCheckboxColumn: false,
                                    columns: [
                                      DataColumn(label: Text(auID, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auNome, style: headerTextStyle(),)),
                                      DataColumn(label: Text(auDescrizione, style: headerTextStyle(),)),
                                    ],
                                    rows: snapshot.data!.map((e) {
                                      return DataRow(
                                          onSelectChanged: (bool? selected) {
                                            if(selected != null && selected) {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(builder: (context) => ManageUserOrGroup(manageUser: showUsers, entityID: e.id,))
                                              );
                                            }
                                          },
                                          cells: <DataCell> [
                                            DataCell(Text(e.id.toString())),
                                            DataCell(Text(e.nome)),
                                            DataCell(Text(e.descrizione)),
                                          ]
                                      );
                                    }).toList(),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }
                        return const CircularProgressIndicator();
                      },
                    ),
                  ]
              ),
            )
        ),
      ),
    );
  }
}
