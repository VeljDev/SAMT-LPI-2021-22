import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:phone_form_field/phone_form_field.dart';
import 'package:provider/provider.dart';
import 'package:track/templates/constants.dart';
import 'package:track/templates/widgets.dart';

import '../../database/database.dart';

class ManageUserOrGroup extends StatefulWidget {
  final bool manageUser;
  final int entityID;
  const ManageUserOrGroup({Key? key, required this.manageUser, required this.entityID}) : super(key: key);

  @override
  State<ManageUserOrGroup> createState() => _ManageUserOrGroupState();
}

class _ManageUserOrGroupState extends State<ManageUserOrGroup> {

  final _formKey = GlobalKey<FormState>();
  final _motivazioneKey = GlobalKey<FormState>();
  bool anyGroupAvailable = false;
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _nomeGruppo = TextEditingController();
  final TextEditingController _cognome = TextEditingController();
  final TextEditingController _descrizione = TextEditingController();
  String? _sesso = auMaschio;
  final TextEditingController _cellulare = TextEditingController();
  final TextEditingController _indirizzo = TextEditingController();
  final TextEditingController _cap = TextEditingController();
  final TextEditingController _localita = TextEditingController();
  final TextEditingController _dataNascita = TextEditingController();
  final TextEditingController _dataAffiliazione = TextEditingController();
  final TextEditingController _motivazione = TextEditingController();
  String? _tipo;
  String? _grado;
  String? _ruolo;
  int? _gruppo;
  final TextEditingController _note = TextEditingController();

  @override
  void initState() {
    super.initState();
    if(widget.manageUser) {
      WidgetsBinding.instance?.addPostFrameCallback((_) async {
        List<GetEveryNomeGruppoResult> temp = await loadGroups(context);
        _changeState(temp.isNotEmpty);
        await loadUserData(context);
      });
    }else {
      WidgetsBinding.instance?.addPostFrameCallback((_) async {
        await loadGroupsData(context);
      });
    }
  }

  // Ritorno i dati del dipendente in questione dal DB.
  Future<void> loadUserData(context) async {
    DipendenteData data = await Provider.of<AppDb>(context, listen: false).getDipendenteFromID(widget.entityID).getSingle();
    _nome.text = data.nome;
    _cognome.text = data.cognome;
    _sesso = data.sesso;
    _cellulare.text = data.cellulare;
    _indirizzo.text = data.indirizzo;
    _cap.text = data.cap.toString();
    _localita.text = data.localita;
    _dataNascita.text = data.dataNascita;
    _dataAffiliazione.text = data.dataAffiliazione;
    _tipo = data.tipo;
    _grado = data.grado;
    _ruolo = data.ruolo;
    _gruppo = data.gruppo;
    _note.text = data.note ?? '';
  }

  // Ritorno i dati del del gruppo in questione dal DB.
  Future<void> loadGroupsData(context) async {
    GruppoData data = await Provider.of<AppDb>(context, listen: false).getGruppoFromID(widget.entityID).getSingle();
    _nomeGruppo.text = data.nome;
    _descrizione.text = data.descrizione;
  }

  // Ritorno tutti i gruppi presenti nel DB.
  Future<List<GetEveryNomeGruppoResult>> loadGroups(context) async {
    return await Provider.of<AppDb>(context, listen: false).getEveryNomeGruppo().get();
  }

  // Indico che ci sono dei gruppi disponibili.
  void _changeState(bool value) {
    setState(() {
      anyGroupAvailable = value;
    });
  }

  // Verifico che una data sia valida.
  bool _isDateValid(String date) {
    DateFormat format = DateFormat('dd/MM/yyyy');
    try {
      DateTime finalDate = format.parseStrict(date);
      return finalDate.year > 1920;
    } catch (e) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar('Gestione ' + (widget.manageUser ? 'utente' : 'gruppo')),
      body: Center(
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 50),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Modifica i seguenti campi:', style: subtitleTextStyle(),),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il tuo nome',
                        labelText: 'Nome',
                      ),
                      controller: _nome,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il nome del gruppo',
                        labelText: 'Nome del gruppo',
                      ),
                      controller: _nomeGruppo,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il tuo cognome',
                        labelText: 'Cognome',
                      ),
                      controller: _cognome,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci la descrizione',
                        labelText: 'Descrizione',
                      ),
                      controller: _descrizione,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                      width: MediaQuery.of(context).size.width * 0.2,
                      child: DropdownButtonFormField(
                        items: const [
                          DropdownMenuItem(child: Text(auMaschio), value: auMaschio,),
                          DropdownMenuItem(child: Text(auFemmina), value: auFemmina,),
                        ],
                        value: _sesso,
                        onChanged: (String? value) {
                          setState(() {
                            _sesso = value;
                          });
                        },
                        validator: (value) {
                          return null;
                        },
                      )
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Es. : +41 076 123 45 67',
                        labelText: 'Numero cellulare',
                      ),
                      controller: _cellulare,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }

                        try {
                          PhoneNumber phone = PhoneNumber.fromRaw(value);
                          return phone.validate() ? null : 'Numero cellulare non valido!';
                        }catch(e) {
                          return 'Numero cellulare non valido!';
                        }
                      },
                    ),
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il tuo indirizzo',
                        labelText: 'Indirizzo',
                      ),
                      controller: _indirizzo,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il CAP',
                        labelText: 'CAP',
                      ),
                      controller: _cap,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }
                        if(int.tryParse(value) == null) {
                          return 'CAP non valido';
                        }
                        return null;
                      },
                    ),
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci la località',
                        labelText: 'Località',
                      ),
                      controller: _localita,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'gg/mm/aaaa',
                        labelText: 'Data di nascita',
                      ),
                      controller: _dataNascita,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }

                        return _isDateValid(value) ? null : 'Data non valida!';
                      },
                    ),
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'gg/mm/aaaa',
                        labelText: 'Data di affiliazione',
                      ),
                      controller: _dataAffiliazione,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }

                        return _isDateValid(value) ? null : 'Data non valida!';
                      },
                    ),
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryTipo().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<TipoData>> snapshot) {
                      if(snapshot.hasData) {
                        return SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il tipo:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.valore),
                                value: element,
                              );
                            }).toList(),
                            value: TipoData(valore: _tipo!),
                            onChanged: (TipoData? value) { _tipo = value!.valore; },
                            onSaved: (TipoData? value) { _tipo = value!.valore; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        );
                      }

                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryGrado().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<GradoData>> snapshot) {
                      if(snapshot.hasData) {
                        return SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il grado:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.valore),
                                value: element,
                              );
                            }).toList(),
                            value: GradoData(valore: _grado!),
                            onChanged: (GradoData? value) { _grado = value!.valore; },
                            onSaved: (GradoData? value) { _grado = value!.valore; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        );
                      }

                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryRuolo().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<RuoloData>> snapshot) {
                      if(snapshot.hasData) {
                        return SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il ruolo:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.valore),
                                value: element,
                              );
                            }).toList(),
                            value: RuoloData(valore: _ruolo!),
                            onChanged: (RuoloData? value) { _ruolo = value!.valore; },
                            onSaved: (RuoloData? value) { _ruolo = value!.valore; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        );
                      }
                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryNomeGruppo().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<GetEveryNomeGruppoResult>> snapshot) {
                      if(snapshot.hasData) {
                        return snapshot.data!.isNotEmpty ? SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il gruppo:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.nome),
                                value: element.id,
                              );
                            }).toList(),
                            value: _gruppo,
                            onChanged: (int? value) { _gruppo = value!; },
                            onSaved: (int? value) { _gruppo = value!; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        ) : const Text(
                          'Nessun gruppo disponibile',
                          style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                        );
                      }
                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.manageUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.manageUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci le note (opzionale)',
                        labelText: 'Note',
                      ),
                      controller: _note,
                      validator: (value) {
                        return null;
                      },
                    ),
                  ) : Container(),
                  const SizedBox(
                    height: 30,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.green
                        ),
                        onPressed: widget.manageUser && !anyGroupAvailable ? null : () async {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            if(widget.manageUser) {
                              await showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text('Motivazione'),
                                  content: Form(
                                    key: _motivazioneKey,
                                    child: TextFormField(
                                      decoration: const InputDecoration(
                                        border: UnderlineInputBorder(),
                                        hintText: 'Aggiungi una motivazione alle modifiche',
                                        labelText: 'Motivazione',
                                      ),
                                      controller: _motivazione,
                                      validator: (value) {
                                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                                      },
                                    ),
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () async {
                                        if(_motivazioneKey.currentState!.validate()) {
                                          await Provider.of<AppDb>(context, listen: false).insertStorico(
                                            DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now()),
                                            _descrizione.text,
                                            widget.entityID
                                          );
                                          Navigator.pop(context);
                                        }
                                      },
                                      child: const Text('Salva'),
                                    ),
                                    TextButton(
                                      onPressed: () {
                                        Navigator.pop(context, 'Annulla');
                                      },
                                      child: const Text('Annulla'),
                                    ),
                                  ],
                                ),
                                barrierDismissible: false,
                              ).then((value) async {
                                if(value != null && value == 'Annulla') {
                                  return;
                                }
                                await Provider.of<AppDb>(context, listen: false).updateDipendente(
                                  _nome.text,
                                  _cognome.text,
                                  _sesso!,
                                  _cellulare.text,
                                  _indirizzo.text,
                                  int.tryParse(_cap.text)!,
                                  _localita.text,
                                  _dataNascita.text,
                                  _dataAffiliazione.text,
                                  _tipo!,
                                  _grado!,
                                  _ruolo!,
                                  _gruppo!,
                                  _note.text,
                                  widget.entityID
                                );
                                Navigator.pop(context);
                              });
                            }else {
                              await Provider.of<AppDb>(context, listen: false).updateGruppo(
                                _nomeGruppo.text,
                                _descrizione.text,
                                widget.entityID
                              );
                              Navigator.pop(context);
                            }
                          }
                        },
                        child: const Text('Salva e chiudi'),
                      ),
                      const SizedBox(
                        width: 50,
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.red
                        ),
                        onPressed: widget.manageUser && !anyGroupAvailable ? null : () async {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            await showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text('Attenzione!'),
                                content: Text(
                                  'Sei sicuro di voler eliminare ' + (widget.manageUser ?
                                  'l\'utente?' : 'il gruppo?'
                                  )
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context, 'Sì');
                                    },
                                    child: const Text('Sì'),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context, 'No');
                                    },
                                    child: const Text('No'),
                                  ),
                                ],
                              ),
                              barrierDismissible: false
                            ).then((value) async {
                              if(value == 'Sì') {
                                if(widget.manageUser) {
                                  await Provider.of<AppDb>(context, listen: false).deleteDipendente(
                                    widget.entityID
                                  );
                                }else {
                                  await Provider.of<AppDb>(context, listen: false).deleteGruppo(
                                    widget.entityID
                                  );
                                }
                                Navigator.pop(context);
                              }
                            });
                          }
                        },
                        child: const Text('Elimina'),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}