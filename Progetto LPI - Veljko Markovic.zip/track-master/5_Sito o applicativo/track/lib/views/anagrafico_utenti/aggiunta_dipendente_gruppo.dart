import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:phone_form_field/phone_form_field.dart';
import 'package:provider/provider.dart';
import 'package:track/templates/constants.dart';
import 'package:track/templates/widgets.dart';

import '../../database/database.dart';

class AddUserOrGroup extends StatefulWidget {
  final bool addUser;
  const AddUserOrGroup({Key? key, required this.addUser}) : super(key: key);

  @override
  State<AddUserOrGroup> createState() => _AddUserOrGroupState();
}

class _AddUserOrGroupState extends State<AddUserOrGroup> {

  final _formKey = GlobalKey<FormState>();
  bool anyGroupAvailable = false;
  int _nextGroupId = 1;
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _nomeGruppo = TextEditingController();
  final TextEditingController _cognome = TextEditingController();
  final TextEditingController _descrizione = TextEditingController();
  String? _sesso = auMaschio;
  final TextEditingController _cellulare = TextEditingController();
  final TextEditingController _indirizzo = TextEditingController();
  final TextEditingController _cap = TextEditingController();
  final TextEditingController _localita = TextEditingController();
  final TextEditingController _dataNascita = TextEditingController();
  final TextEditingController _dataAffiliazione = TextEditingController();
  String? _tipo;
  String? _grado;
  String? _ruolo;
  int? _gruppo;
  final TextEditingController _note = TextEditingController();

  @override
  void initState() {
    super.initState();
    if(widget.addUser) {
      WidgetsBinding.instance?.addPostFrameCallback((_) async {
        List<GetEveryNomeGruppoResult> temp = await loadGroups(context);
        _changeState(temp.isNotEmpty);
      });
    }else {
      WidgetsBinding.instance?.addPostFrameCallback((_) async {
        await _updateGroupsIndex(context);
      });
    }
  }

  // Ritorno tutti i gruppi dal DB.
  Future<List<GetEveryNomeGruppoResult>> loadGroups(context) async {
    return await Provider.of<AppDb>(context, listen: false).getEveryNomeGruppo().get();
  }

  // Ritorno l'ultimo numero disponibile per l'ID del gruppo.
  Future<int?> loadGroupsIndex(context) async {
    return await Provider.of<AppDb>(context, listen: false).getNextAutoincrementID().getSingleOrNull();
  }

  // Aggiorno il prossimo numero disponibile per l'ID del gruppo.
  Future<void> _updateGroupsIndex(context) async {
    int? temp = await loadGroupsIndex(context);
    setState(() {
      _nextGroupId = temp != null ? temp + 1 : 1;
    });
  }

  // Indico che ci sono dei gruppi disponibili.
  void _changeState(bool value) {
    setState(() {
      anyGroupAvailable = value;
    });
  }

  // Pulisco gli input del form.
  void _clearForm() {
    _nome.clear();
    _nomeGruppo.clear();
    _cognome.clear();
    _descrizione.clear();
    _cellulare.clear();
    _indirizzo.clear();
    _cap.clear();
    _localita.clear();
    _dataNascita.clear();
    _dataAffiliazione.clear();
    _note.clear();
    setState(() {
      _sesso = auMaschio;
    });
  }

  // Verifico che una data sia valida.
  bool _isDateValid(String date) {
    DateFormat format = DateFormat('dd/MM/yyyy');
    try {
      DateTime finalDate = format.parseStrict(date);
      return finalDate.year > 1920;
    } catch (e) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar('Aggiunta ' + (widget.addUser ? 'utente' : 'gruppo')),
      body: Center(
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 50),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Compila i seguenti campi:', style: subtitleTextStyle(),),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il tuo nome',
                        labelText: 'Nome',
                      ),
                      controller: _nome,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il nome del gruppo',
                        labelText: 'Nome del gruppo',
                      ),
                      controller: _nomeGruppo,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il tuo cognome',
                        labelText: 'Cognome',
                      ),
                      controller: _cognome,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci la descrizione',
                        labelText: 'Descrizione',
                      ),
                      controller: _descrizione..text = 'Gruppo - ' + _nextGroupId.toString(),
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: DropdownButtonFormField(
                      items: const [
                        DropdownMenuItem(child: Text(auMaschio), value: auMaschio,),
                        DropdownMenuItem(child: Text(auFemmina), value: auFemmina,),
                      ],
                      value: _sesso,
                      onChanged: (String? value) {
                        setState(() {
                          _sesso = value;
                        });
                      },
                      validator: (value) {
                        return null;
                      },
                    )
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Es. : +41 076 123 45 67',
                        labelText: 'Numero cellulare',
                      ),
                      controller: _cellulare,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }

                        try {
                          PhoneNumber phone = PhoneNumber.fromRaw(value);
                          return phone.validate() ? null : 'Numero cellulare non valido!';
                        }catch(e) {
                          return 'Numero cellulare non valido!';
                        }
                      },
                    ),
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il tuo indirizzo',
                        labelText: 'Indirizzo',
                      ),
                      controller: _indirizzo,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci il CAP',
                        labelText: 'CAP',
                      ),
                      controller: _cap,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }
                        if(int.tryParse(value) == null) {
                          return 'CAP non valido';
                        }
                        return null;
                      },
                    ),
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci la località',
                        labelText: 'Località',
                      ),
                      controller: _localita,
                      validator: (value) {
                        return value != null && value.isNotEmpty ? null : 'Il campo non può essere vuoto!';
                      },
                    ),
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'gg/mm/aaaa',
                        labelText: 'Data di nascita',
                      ),
                      controller: _dataNascita,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }

                        return _isDateValid(value) ? null : 'Data non valida!';
                      },
                    ),
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'gg/mm/aaaa',
                        labelText: 'Data di affiliazione',
                      ),
                      controller: _dataAffiliazione,
                      validator: (value) {
                        if(value == null || value.isEmpty) {
                          return 'Il campo non può essere vuoto!';
                        }

                        return _isDateValid(value) ? null : 'Data non valida!';
                      },
                    ),
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryTipo().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<TipoData>> snapshot) {
                      if(snapshot.hasData) {
                        return SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il tipo:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.valore),
                                value: element,
                              );
                            }).toList(),
                            value: snapshot.data!.first,
                            onChanged: (TipoData? value) { _tipo = value!.valore; },
                            onSaved: (TipoData? value) { _tipo = value!.valore; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        );
                      }

                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryGrado().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<GradoData>> snapshot) {
                      if(snapshot.hasData) {
                        return SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il grado:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.valore),
                                value: element,
                              );
                            }).toList(),
                            value: snapshot.data!.first,
                            onChanged: (GradoData? value) { _grado = value!.valore; },
                            onSaved: (GradoData? value) { _grado = value!.valore; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        );
                      }

                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryRuolo().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<RuoloData>> snapshot) {
                      if(snapshot.hasData) {
                        return SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il ruolo:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.valore),
                                value: element,
                              );
                            }).toList(),
                            value: snapshot.data!.first,
                            onChanged: (RuoloData? value) { _ruolo = value!.valore; },
                            onSaved: (RuoloData? value) { _ruolo = value!.valore; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        );
                      }
                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? StreamBuilder(
                    stream: Provider.of<AppDb>(context).getEveryNomeGruppo().watch(),
                    builder: (BuildContext context, AsyncSnapshot<List<GetEveryNomeGruppoResult>> snapshot) {
                      if(snapshot.hasData) {
                        return snapshot.data!.isNotEmpty ? SizedBox(
                          width: MediaQuery.of(context).size.width * 0.2,
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                                label: Text('Seleziona il gruppo:', style: labelTextStyle(),)
                            ),
                            items: snapshot.data!.map((element) {
                              return DropdownMenuItem(
                                child: Text(element.nome),
                                value: element.id,
                              );
                            }).toList(),
                            value: snapshot.data!.first.id,
                            onChanged: (int? value) { _gruppo = value!; },
                            onSaved: (int? value) { _gruppo = value!; },
                            validator: (value) {
                              return value != null ? null : 'Il campo non può essere vuoto!';
                            },
                          ),
                        ) : const Text(
                          'Nessun gruppo disponibile',
                          style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                        );
                      }
                      return const CircularProgressIndicator();
                    },
                  ) : Container(),
                  widget.addUser ? const SizedBox(
                    height: 20,
                  ) : Container(),
                  widget.addUser ? SizedBox(
                    width: MediaQuery.of(context).size.width * 0.2,
                    child: TextFormField(
                      decoration: const InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: 'Inserisci le note (opzionale)',
                        labelText: 'Note',
                      ),
                      controller: _note,
                      validator: (value) {
                        return null;
                      },
                    ),
                  ) : Container(),
                  const SizedBox(
                    height: 30,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: Colors.blue
                        ),
                        onPressed: widget.addUser && !anyGroupAvailable ? null : () async {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            if(widget.addUser) {
                              await Provider.of<AppDb>(context, listen: false).insertDipendente(
                                _nome.text,
                                _cognome.text,
                                _sesso!,
                                _cellulare.text,
                                _indirizzo.text,
                                int.tryParse(_cap.text)!,
                                _localita.text,
                                _dataNascita.text,
                                _dataAffiliazione.text,
                                _tipo!,
                                _grado!,
                                _ruolo!,
                                _gruppo!,
                                _note.text
                              );
                            }else {
                              await Provider.of<AppDb>(context, listen: false).insertGruppo(
                                _nomeGruppo.text,
                                _descrizione.text
                              );
                            }
                            Navigator.pop(context);
                          }
                        },
                        child: const Text('Aggiungi e chiudi'),
                      ),
                      const SizedBox(
                        width: 50,
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.green
                        ),
                        onPressed: widget.addUser && !anyGroupAvailable ? null : () async {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            if(widget.addUser) {
                              await Provider.of<AppDb>(context, listen: false).insertDipendente(
                                _nome.text,
                                _cognome.text,
                                _sesso!,
                                _cellulare.text,
                                _indirizzo.text,
                                int.tryParse(_cap.text)!,
                                _localita.text,
                                _dataNascita.text,
                                _dataAffiliazione.text,
                                _tipo!,
                                _grado!,
                                _ruolo!,
                                _gruppo!,
                                _note.text
                              );
                              _clearForm();
                            }else {
                              await Provider.of<AppDb>(context, listen: false).insertGruppo(
                                _nomeGruppo.text,
                                _descrizione.text
                              );
                              _clearForm();
                              await _updateGroupsIndex(context);
                            }
                          }
                        },
                        child: const Text('Aggiungi'),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
