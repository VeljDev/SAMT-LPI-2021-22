import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:track/database/database.dart';
import 'package:track/templates/constants.dart';
import 'package:track/views/main_menu.dart';
import 'package:window_size/window_size.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Imposto il titolo, la grandezza minima e massima della finestra.
  setWindowTitle(windowTitle);
  setWindowMinSize(const Size(windowWidth, windowHeight));
  setWindowMaxSize(Size.infinite);

  // Avvio l'applicativo inizializzando il DB nel provider.
  runApp(
    Provider<AppDb>(
      create: (context) => AppDb(),
      child: const MyApp(),
      dispose: (context, db) => db.close(),
    )
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: windowTitle,
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: const MainMenu(),
    );
  }
}