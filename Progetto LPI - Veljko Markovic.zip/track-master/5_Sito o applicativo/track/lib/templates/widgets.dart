import 'package:flutter/material.dart';

AppBar appBar(String title) {
  return AppBar(
    title: Text(title),
  );
}

TextStyle titleTextStyle() {
  return const TextStyle(
    fontSize: 68,
    fontWeight: FontWeight.w500
  );
}

TextStyle subtitleTextStyle() {
  return const TextStyle(
      fontSize: 34,
      fontWeight: FontWeight.w400
  );
}

TextStyle iconTextStyle() {
  return const TextStyle(
      fontSize: 25,
      fontWeight: FontWeight.w300
  );
}

TextStyle labelTextStyle() {
  return const TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.w500
  );
}

TextStyle headerTextStyle() {
  return const TextStyle(
      fontWeight: FontWeight.bold
  );
}