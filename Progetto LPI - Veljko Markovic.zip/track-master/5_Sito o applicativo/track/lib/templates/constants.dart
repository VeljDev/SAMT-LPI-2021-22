//region Window settings
const String windowTitle = 'Track';
const double windowWidth = 1280;
const double windowHeight = 720;
//endregion

//region Anagrafico utenti settings
const String utenti = 'Utenti';
const String gruppi = 'Gruppi';
const String auID = 'ID';
const String auNome = 'Nome';
const String auDescrizione = 'Descrizione';
const String auCognome = 'Cognome';
const String auSesso = 'Sesso';
const String auCellulare = 'Cellulare';
const String auIndirizzo = 'Indirizzo';
const String auCAP = 'CAP';
const String auLocalita = 'Località';
const String auDataNascita = 'Data di nascita';
const String auDataAffiliazione = 'Data di affiliazione';
const String auTipo = 'Tipo';
const String auGrado = 'Grado';
const String auRuolo = 'Ruolo';
const String auGruppo = 'Gruppo';
const String auNote = 'Note';
const String auMaschio = 'Maschio';
const String auFemmina = 'Femmina';
//endregion

//region Rapporti
const int meseDiPartenza = 3;
const String singoloImpiegato = 'Singolo impiegato';
const String tuttiImpiegati = 'Tutti gli impiegati';
const String listaMensileValoriImpiegati = 'Lista mensile dei valori degli impiegati';
const String totaleMensileDellaSomma = 'Totale mensile della somma di tutti i valori';
const String rapportoAnnuale = 'Annuale con totale dei valori mensili';
//endregion

