# Track - Progetto LPI 2021/22

- **Allievo:** Veljko Markovic
- **Superiore:** professionale: Fabio Piccioni
- **Perito 1:** Gianluca Costante
- **Perito 2:** Roberto Guidi
- **Tempo a disposizione:** 02.05.2022 - 25.05.2022
- **Presentazione:** 03.06.2022, dalle 15:40 alle 16:40

# Istruzioni di installazione

In questa sezione sono presenti le istruzioni per poter installare l'applicativo Track.

## Preliminari

- Per poter installare l'applicativo, occorre scaricare il file [track.msix](/5_Sito o applicativo/Release/track.msix).
- Se non si dispone di un computer Windows 10 con la versione minima 1709, è possibile scaricare la VM messa a disposizione su SwissTransfer su questo [link](https://www.swisstransfer.com/d/338272a7-a9e4-40b1-8779-a89e1b4c4e93).

**N.B.: Il link per il download della VM scade in data 23.06.2022 alle ore 11:48. Inoltre, prima di accendere la VM verificare che le specifiche HW di quest'ultima siano adatte al vostro PC.**

## Installazione
Le istruzioni per installare l'applicativo sono descritte dettagliatamente nella [documentazione](/3_Documentazione %28word e pdf%29/Documentazione Track - Markovic.pdf) nel capitolo **4.9.1 - Installazione di Track**.
Infine, dopo aver installato l'applicativo, **prima** di farlo partire, scaricare il file [track.sqlite](/6_Database/track.sqlite) e inserirlo nella cartella Documenti.